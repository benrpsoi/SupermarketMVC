from docx import Document

doc_path = r'c:\Users\Benedict Tay\Downloads\CA2_C372_Kyan\C372_Individual_CA2_AI_Interaction_Journal_240221821_benedict (1).docx'
doc = Document(doc_path)

print("="*80)
print("DOCUMENT CONTENT")
print("="*80)

for para in doc.paragraphs:
    if para.text.strip():
        print(para.text)

print("\n" + "="*80)
print("TABLES")
print("="*80)

for table_idx, table in enumerate(doc.tables):
    print(f"\nTable {table_idx + 1}:")
    for row_idx, row in enumerate(table.rows):
        row_text = []
        for cell in row.cells:
            row_text.append(cell.text.strip())
        print(" | ".join(row_text))
