const SupportTicket = require('../models/SupportTicket');
const db = require('../db');

const SupportController = {
    // User - Show support page
    showSupport(req, res) {
        res.render('support', { user: req.session.user || null });
    },

    // User - Create new ticket
    createTicket(req, res) {
        const { name, email, issueType, message } = req.body;
        const userId = req.session.user ? req.session.user.id : null;

        if (!name || !email || !issueType || !message) {
            req.flash('error', 'All fields are required');
            return res.redirect('/support');
        }

        const ticket = { userId, name, email, issueType, message };

        SupportTicket.create(ticket, (err, result) => {
            if (err) {
                console.error('Ticket creation error:', err);
                req.flash('error', 'Failed to create support ticket');
                return res.redirect('/support');
            }
            req.flash('success', 'Your support ticket has been created. Our team will respond soon!');
            res.redirect('/support');
        });
    },

    // User - View their tickets
    myTickets(req, res) {
        const userId = req.session.user.id;

        SupportTicket.getByUserId(userId, (err, tickets) => {
            if (err) {
                console.error('Fetch tickets error:', err);
                req.flash('error', 'Failed to load tickets');
                return res.redirect('/support');
            }
            res.render('my-tickets', { user: req.session.user, tickets });
        });
    },

    // Admin - Show all tickets dashboard
    adminTickets(req, res) {
        SupportTicket.getAll((err, tickets) => {
            if (err) {
                console.error('Fetch all tickets error:', err);
                req.flash('error', 'Failed to load tickets');
                return res.redirect('/inventory');
            }
            res.render('admin-tickets', { user: req.session.user, tickets });
        });
    },

    // Admin - Get single ticket for reply modal
    getTicket(req, res) {
        const ticketId = req.params.id;

        SupportTicket.getById(ticketId, (err, results) => {
            if (err || results.length === 0) {
                return res.status(404).json({ error: 'Ticket not found' });
            }
            res.json(results[0]);
        });
    },

    // Admin - Reply to ticket
    replyTicket(req, res) {
        const ticketId = req.params.id;
        const { reply } = req.body;
        const adminName = req.session.user.username;

        if (!reply) {
            req.flash('error', 'Reply message is required');
            return res.redirect('/admin/tickets');
        }

        SupportTicket.addReply(ticketId, reply, adminName, (err) => {
            if (err) {
                console.error('Reply error:', err);
                req.flash('error', 'Failed to send reply');
                return res.redirect('/admin/tickets');
            }
            req.flash('success', 'Reply sent successfully');
            res.redirect('/admin/tickets');
        });
    },

    // Admin - Update ticket status
    updateTicketStatus(req, res) {
        const ticketId = req.params.id;
        const { status } = req.body;

        if (!['open', 'in-progress', 'resolved'].includes(status)) {
            return res.status(400).json({ error: 'Invalid status' });
        }

        SupportTicket.updateStatus(ticketId, status, (err) => {
            if (err) {
                console.error('Update status error:', err);
                return res.status(500).json({ error: 'Failed to update status' });
            }
            res.json({ success: true, message: 'Status updated' });
        });
    },

    // Admin - Search tickets
    searchTickets(req, res) {
        const { search } = req.query;

        if (!search) {
            return res.redirect('/admin/tickets');
        }

        SupportTicket.searchTickets(search, (err, results) => {
            if (err) {
                console.error('Search error:', err);
                req.flash('error', 'Search failed');
                return res.redirect('/admin/tickets');
            }
            res.render('admin-tickets', { user: req.session.user, tickets: results });
        });
    }
};

module.exports = SupportController;
