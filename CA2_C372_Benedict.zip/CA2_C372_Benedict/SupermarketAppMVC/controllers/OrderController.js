const Order = require('../models/Order');

const OrderController = {
  // POST /checkout - Old checkout directly creates order
  checkout(req, res) {
    const user = req.session.user;
    const cart = req.session.cart || [];

    if (!user) return res.status(401).send('Not authenticated');
    if (cart.length === 0) {
      req.flash('error', 'Cart is empty');
      return res.redirect('/cart');
    }

    Order.create(user.id, cart, (err, result) => {
      if (err) {
        console.error('Error creating order:', err);
        req.flash('error', 'Could not create order');
        return res.redirect('/cart');
      }

      // Clear cart and redirect to order history or invoice
      req.session.cart = [];
      req.flash('success', 'Order placed successfully');
      return res.redirect(`/orders/${result.orderId}/invoice`);
    });
  },

  // POST /checkout-nets - New checkout that redirects to NETS payment
  checkoutNets(req, res) {
    const user = req.session.user;
    const cart = req.session.cart || [];

    if (!user) return res.status(401).send('Not authenticated');
    if (cart.length === 0) {
      req.flash('error', 'Cart is empty');
      return res.redirect('/cart');
    }

    // Calculate total
    let cartTotal = 0;
    cart.forEach(item => {
      cartTotal += item.price * item.quantity;
    });

    // Render a form that will submit to the NETS QR generation endpoint
    res.render('checkoutNets', { 
      cart, 
      user: req.session.user,
      cartTotal: cartTotal.toFixed(2)
    });
  },

  // GET /checkout-paypal - Checkout that shows PayPal payment
  checkoutPaypal(req, res) {
    const user = req.session.user;
    const cart = req.session.cart || [];

    if (!user) return res.status(401).send('Not authenticated');
    if (cart.length === 0) {
      req.flash('error', 'Cart is empty');
      return res.redirect('/cart');
    }

    // Calculate total
    let cartTotal = 0;
    cart.forEach(item => {
      cartTotal += item.price * item.quantity;
    });

    // Render the PayPal checkout page
    res.render('checkoutPaypal', { 
      cart, 
      user: req.session.user,
      cartTotal: cartTotal.toFixed(2)
    });
  },

  // GET /checkout-stripe - Checkout that shows Stripe payment
  checkoutStripe(req, res) {
    const user = req.session.user;
    const cart = req.session.cart || [];

    if (!user) return res.status(401).send('Not authenticated');
    if (cart.length === 0) {
      req.flash('error', 'Cart is empty');
      return res.redirect('/cart');
    }

    // Calculate total
    let cartTotal = 0;
    cart.forEach(item => {
      cartTotal += item.price * item.quantity;
    });

    // Render the Stripe checkout page
    res.render('checkoutStripe', { 
      cart, 
      user: req.session.user,
      cartTotal: cartTotal.toFixed(2)
    });
  },

  // GET /checkout-wallet - Checkout with wallet
  checkoutWallet(req, res) {
    const user = req.session.user;
    const cart = req.session.cart || [];

    if (!user) return res.status(401).send('Not authenticated');
    if (cart.length === 0) {
      req.flash('error', 'Cart is empty');
      return res.redirect('/cart');
    }

    // Calculate total
    let cartTotal = 0;
    cart.forEach(item => {
      cartTotal += item.price * item.quantity;
    });

    // Get wallet balance
    const Wallet = require('../models/Wallet');
    Wallet.getBalance(user.id, (err, balance) => {
      if (err) {
        console.error('Error fetching wallet balance:', err);
        balance = 0;
      }

      res.render('checkoutWallet', { 
        cart, 
        user: req.session.user,
        cartTotal: cartTotal.toFixed(2),
        walletBalance: (balance || 0).toFixed(2)
      });
    });
  },

  // GET /orders
  list(req, res) {
    const user = req.session.user;
    if (!user) return res.status(401).send('Not authenticated');

    Order.getByUser(user.id, (err, orders) => {
      if (err) {
        console.error('Error fetching orders:', err);
        return res.status(500).send('Database error');
      }
      res.render('orders', { orders, user });
    });
  },

  // GET /orders/:id/invoice
  invoice(req, res) {
    const id = req.params.id;
    const user = req.session.user;

    if (!user) return res.status(401).send('Not authenticated');

    Order.getById(id, (err, order) => {
      if (err) {
        console.error('Error fetching invoice:', err);
        return res.status(500).send('Database error');
      }
      if (!order) return res.status(404).send('Order not found');

      // Ensure this order belongs to the current user (unless admin)
      if (order.user_id !== user.id && user.role !== 'admin') {
        return res.status(403).send('Forbidden');
      }

      res.render('invoice', { order, user });
    });
  },

  // Process PayPal payment after capture
  processPayPalPayment(req, res, capture) {
    const user = req.session.user;
    const cart = req.session.cart || [];

    if (!user) return res.status(401).json({ error: 'Not authenticated' });
    if (cart.length === 0) {
      return res.status(400).json({ error: 'Cart is empty' });
    }

    // Extract transaction details from PayPal response
    const isoString = capture.purchase_units[0].payments.captures[0].create_time;
    const mysqlDatetime = isoString.replace("T", " ").replace("Z", "");

    const transaction = {
      orderId: capture.id,
      payerId: capture.payer.payer_id,
      payerEmail: capture.payer.email_address,
      amount: capture.purchase_units[0].payments.captures[0].amount.value,
      currency: capture.purchase_units[0].payments.captures[0].amount.currency_code,
      status: capture.status,
      time: mysqlDatetime,
    };

    // Create the order
    Order.create(user.id, cart, (err, result) => {
      if (err) {
        console.error('Error creating order:', err);
        return res.status(500).json({ error: 'Could not create order', message: err.message });
      }

      // Clear cart
      req.session.cart = [];

      // Respond with success
      res.json({ success: true, transaction, orderId: result.orderId });
    });
  },

  // Process Stripe payment after confirmation
  processStripePayment(req, res, paymentIntent) {
    const user = req.session.user;
    const cart = req.session.cart || [];

    if (!user) return res.status(401).json({ error: 'Not authenticated' });
    if (cart.length === 0) {
      return res.status(400).json({ error: 'Cart is empty' });
    }

    // Extract transaction details from Stripe response
    const mysqlDatetime = new Date(paymentIntent.created * 1000).toISOString().slice(0, 19).replace('T', ' ');

    const transaction = {
      orderId: paymentIntent.id,
      payerId: paymentIntent.payment_method,
      payerEmail: paymentIntent.receipt_email || 'N/A',
      amount: (paymentIntent.amount / 100).toFixed(2), // Convert from cents
      currency: paymentIntent.currency.toUpperCase(),
      status: paymentIntent.status,
      time: mysqlDatetime,
    };

    // Create the order
    Order.create(user.id, cart, (err, result) => {
      if (err) {
        console.error('Error creating order:', err);
        return res.status(500).json({ error: 'Could not create order', message: err.message });
      }

      // Clear cart
      req.session.cart = [];

      // Respond with success
      res.json({ success: true, transaction, orderId: result.orderId });
    });
  },

  // GET /orders/:id/request-refund - Show refund request form
  showRefundRequestForm(req, res) {
    const orderId = parseInt(req.params.id);
    const user = req.session.user;

    Order.getById(orderId, (err, order) => {
      if (err) {
        console.error('Error fetching order:', err);
        req.flash('error', 'Could not fetch order');
        return res.redirect('/orders');
      }

      if (!order || order.user_id !== user.id) {
        req.flash('error', 'Order not found');
        return res.redirect('/orders');
      }

      res.render('request-refund', { order, user });
    });
  },

  // POST /orders/:id/request-refund - Submit refund request
  requestRefund(req, res) {
    const orderId = parseInt(req.params.id);
    const user = req.session.user;
    const { refundReason } = req.body;

    if (!refundReason || refundReason.trim().length === 0) {
      req.flash('error', 'Please provide a reason for the refund request');
      return res.redirect(`/orders/${orderId}/request-refund`);
    }

    // Verify order belongs to user
    Order.getById(orderId, (err, order) => {
      if (err || !order || order.user_id !== user.id) {
        req.flash('error', 'Order not found');
        return res.redirect('/orders');
      }

      // Check if order already has a pending refund request
      const Refund = require('../models/Refund');
      Refund.getByOrderId(orderId, (err2, existingRefunds) => {
        if (err2) {
          console.error('Error checking existing refunds:', err2);
          req.flash('error', 'Could not process request');
          return res.redirect('/orders');
        }

        const pendingRequest = existingRefunds && existingRefunds.find(r => r.status === 'pending' && r.requested_by === user.id);
        if (pendingRequest) {
          req.flash('error', 'You already have a pending refund request for this order');
          return res.redirect('/orders');
        }

        // Create refund request
        Refund.requestRefund(orderId, user.id, refundReason, (err3, result) => {
          if (err3) {
            console.error('Error creating refund request:', err3);
            req.flash('error', 'Could not submit refund request');
            return res.redirect('/orders');
          }

          req.flash('success', 'Refund request submitted successfully. An admin will review it shortly.');
          res.redirect('/orders');
        });
      });
    });
  },

  // GET /my-refunds - Show customer's refund requests
  myRefunds(req, res) {
    const user = req.session.user;
    const Refund = require('../models/Refund');

    Refund.getCustomerRefunds(user.id, (err, refunds) => {
      if (err) {
        console.error('Error fetching refund requests:', err);
        req.flash('error', 'Could not fetch refund requests');
        return res.redirect('/orders');
      }

      res.render('my-refunds', { refunds: refunds || [], user });
    });
  },

  // POST /checkout-wallet - Process wallet payment
  processWalletCheckout(req, res) {
    const user = req.session.user;
    const cart = req.session.cart || [];

    if (!user) return res.status(401).send('Not authenticated');
    if (cart.length === 0) {
      req.flash('error', 'Cart is empty');
      return res.redirect('/cart');
    }

    // Calculate total
    let cartTotal = 0;
    cart.forEach(item => {
      cartTotal += item.price * item.quantity;
    });

    // Get wallet balance and check if sufficient
    const Wallet = require('../models/Wallet');
    Wallet.getBalance(user.id, (err, balance) => {
      if (err) {
        console.error('Error fetching wallet balance:', err);
        req.flash('error', 'Could not process wallet payment');
        return res.redirect('/cart');
      }

      const walletBalance = parseFloat(balance || 0);
      if (walletBalance < cartTotal) {
        req.flash('error', `Insufficient wallet balance. You need $${cartTotal.toFixed(2)} but only have $${walletBalance.toFixed(2)}`);
        return res.redirect('/checkout-wallet');
      }

      // Create order
      Order.create(user.id, cart, (err, result) => {
        if (err) {
          console.error('Error creating order:', err);
          req.flash('error', 'Could not create order');
          return res.redirect('/cart');
        }

        // Deduct from wallet
        Wallet.deductFunds(user.id, cartTotal, `Purchase - Order #${result.insertId}`, (err2) => {
          if (err2) {
            console.error('Error deducting from wallet:', err2);
            req.flash('error', 'Order created but could not deduct wallet funds');
            return res.redirect('/orders');
          }

          // Clear cart
          req.session.cart = [];
          req.session.save();

          req.flash('success', `Order placed successfully! $${cartTotal.toFixed(2)} deducted from wallet.`);
          res.redirect(`/orders/${result.insertId}`);
        });
      });
    });
  }
};

module.exports = OrderController;
