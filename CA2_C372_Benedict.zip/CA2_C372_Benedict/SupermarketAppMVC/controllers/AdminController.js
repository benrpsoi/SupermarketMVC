const Order = require('../models/Order');
const Refund = require('../models/Refund');
const stripe = require('../services/stripe');
const paypal = require('../services/paypal');

const AdminController = {
  // GET /admin/orders - Show all orders for refund management
  listOrders(req, res) {
    const user = req.session.user;
    if (!user || user.role !== 'admin') {
      return res.status(403).send('Access denied');
    }

    Order.getAll((err, orders) => {
      if (err) {
        console.error('Error fetching orders:', err);
        return res.status(500).send('Database error');
      }

      res.render('admin/orders', { orders, user });
    });
  },

  // GET /admin/refunds - Show refund management page
  showRefunds(req, res) {
    const user = req.session.user;
    if (!user || user.role !== 'admin') {
      return res.status(403).send('Access denied');
    }

    // Get both admin-processed refunds and customer refund requests
    Refund.getAll((err, refunds) => {
      if (err) {
        console.error('Error fetching refunds:', err);
        return res.status(500).send('Database error');
      }

      Refund.getPendingRequests((err2, pendingRequests) => {
        if (err2) {
          console.error('Error fetching pending requests:', err2);
          pendingRequests = [];
        }

        // Render with both refunds and pending requests
        res.render('admin/refunds', { 
          refunds: refunds || [], 
          pendingRequests: pendingRequests || [],
          user 
        });
      });
    });
  },

  // GET /admin/orders/:id/refund - Show refund form for an order
  showRefundForm(req, res) {
    const user = req.session.user;
    if (!user || user.role !== 'admin') {
      return res.status(403).send('Access denied');
    }

    const orderId = req.params.id;

    Order.getById(orderId, (err, order) => {
      if (err) {
        console.error('Error fetching order:', err);
        return res.status(500).send('Database error');
      }
      if (!order) return res.status(404).send('Order not found');

      // Check if order belongs to current user or if admin
      if (order.user_id !== user.id && user.role !== 'admin') {
        return res.status(403).send('Forbidden');
      }

      Refund.getByOrderId(orderId, (err2, existingRefunds) => {
        if (err2) {
          console.error('Error fetching existing refunds:', err2);
          return res.status(500).send('Database error');
        }

        res.render('admin/refundForm', {
          order,
          existingRefunds: existingRefunds || [],
          user
        });
      });
    });
  },

  // POST /admin/orders/:id/refund - Process refund
  processRefund(req, res) {
    const user = req.session.user;
    if (!user || user.role !== 'admin') {
      return res.status(403).send('Access denied');
    }

    const orderId = req.params.id;
    const { refundType, refundAmount, refundReason, refundItems } = req.body;

    Order.getById(orderId, (err, order) => {
      if (err) {
        console.error('Error fetching order:', err);
        req.flash('error', 'Database error');
        return res.redirect('/admin/refunds');
      }
      if (!order) {
        req.flash('error', 'Order not found');
        return res.redirect('/admin/refunds');
      }

      // Validate refund amount
      const maxRefundable = order.total - (order.refunded_amount || 0);
      if (refundAmount > maxRefundable) {
        req.flash('error', 'Refund amount exceeds available amount');
        return res.redirect(`/admin/orders/${orderId}/refund`);
      }

      // Determine refund method based on order payment
      // This is a simplification - in reality you'd need to track payment method per order
      let refundMethod = 'manual'; // Default to manual
      let transactionId = null;

      // For now, we'll assume we need to manually specify or detect payment method
      // In a real implementation, you'd store payment method with each order

      const refundData = {
        refundAmount: parseFloat(refundAmount),
        refundReason,
        refundMethod,
        transactionId,
        processedBy: user.id,
        refundItems: refundType === 'partial' ? JSON.parse(refundItems || '[]') : null
      };

      Refund.create(orderId, refundData, (err2, result) => {
        if (err2) {
          console.error('Error creating refund:', err2);
          req.flash('error', 'Failed to create refund');
          return res.redirect(`/admin/orders/${orderId}/refund`);
        }

        req.flash('success', 'Refund created successfully');
        res.redirect('/admin/refunds');
      });
    });
  },

  // POST /admin/refunds/:id/process - Process pending refund
  processPendingRefund(req, res) {
    const user = req.session.user;
    if (!user || user.role !== 'admin') {
      return res.status(403).send('Access denied');
    }

    const refundId = req.params.id;

    Refund.getById(refundId, async (err, refund) => {
      if (err) {
        console.error('Error fetching refund:', err);
        req.flash('error', 'Database error');
        return res.redirect('/admin/refunds');
      }
      if (!refund) {
        req.flash('error', 'Refund not found');
        return res.redirect('/admin/refunds');
      }

      try {
        let transactionId = null;

        // Process refund based on method
        if (refund.refund_method === 'stripe') {
          // You'd need to get the payment intent ID from somewhere
          // For now, this is a placeholder
          const stripeRefund = await stripe.createRefund('pi_placeholder', refund.refund_amount, refund.refund_reason);
          transactionId = stripeRefund.id;
        } else if (refund.refund_method === 'paypal') {
          // You'd need to get the capture ID from somewhere
          // For now, this is a placeholder
          const paypalRefund = await paypal.createRefund('capture_placeholder', refund.refund_amount, refund.refund_reason);
          transactionId = paypalRefund.id;
        }
        // For NETS and manual, no API call needed

        // Update refund status
        Refund.updateStatus(refundId, 'completed', transactionId, (err2) => {
          if (err2) {
            console.error('Error updating refund status:', err2);
            req.flash('error', 'Failed to update refund status');
            return res.redirect('/admin/refunds');
          }

          // Restore inventory if partial refund
          if (refund.items && refund.items.length > 0) {
            Refund.restoreInventory(refundId, (err3) => {
              if (err3) {
                console.error('Error restoring inventory:', err3);
                // Don't fail the whole operation for inventory errors
              }

              req.flash('success', 'Refund processed successfully');
              res.redirect('/admin/refunds');
            });
          } else {
            req.flash('success', 'Refund processed successfully');
            res.redirect('/admin/refunds');
          }
        });

      } catch (error) {
        console.error('Error processing refund:', error);
        Refund.updateStatus(refundId, 'failed', null, (err2) => {
          req.flash('error', 'Refund processing failed: ' + error.message);
          res.redirect('/admin/refunds');
        });
      }
    });
  },

  // GET /admin/refunds/:id - View refund details
  viewRefund(req, res) {
    const user = req.session.user;
    if (!user || user.role !== 'admin') {
      return res.status(403).send('Access denied');
    }

    const refundId = req.params.id;

    Refund.getById(refundId, (err, refund) => {
      if (err) {
        console.error('Error fetching refund:', err);
        return res.status(500).send('Database error');
      }
      if (!refund) return res.status(404).send('Refund not found');

      res.render('admin/refundDetails', { refund, user });
    });
  },

  // GET /admin/refund-requests - Show pending customer refund requests
  showRefundRequests(req, res) {
    const user = req.session.user;
    if (!user || user.role !== 'admin') {
      return res.status(403).send('Access denied');
    }

    Refund.getPendingRequests((err, refunds) => {
      if (err) {
        console.error('Error fetching refund requests:', err);
        req.flash('error', 'Could not fetch refund requests');
        return res.redirect('/admin/refunds');
      }

      res.render('admin/refund-requests', { refunds: refunds || [], user });
    });
  },

  // POST /admin/refund-requests/:id/approve - Approve a customer refund request
  approveRefundRequest(req, res) {
    const user = req.session.user;
    if (!user || user.role !== 'admin') {
      return res.status(403).send('Access denied');
    }

    const refundId = req.params.id;

    Refund.approveRefundRequest(refundId, user.id, (err) => {
      if (err) {
        console.error('Error approving refund request:', err);
        req.flash('error', 'Could not approve refund: ' + err.message);
        return res.redirect('/admin/refund-requests');
      }

      req.flash('success', 'Refund request approved and marked as completed');
      res.redirect('/admin/refund-requests');
    });
  },

  // POST /admin/refund-requests/:id/deny - Deny a customer refund request
  denyRefundRequest(req, res) {
    const user = req.session.user;
    if (!user || user.role !== 'admin') {
      return res.status(403).send('Access denied');
    }

    const refundId = req.params.id;

    Refund.denyRefundRequest(refundId, (err) => {
      if (err) {
        console.error('Error denying refund request:', err);
        req.flash('error', 'Could not deny refund: ' + err.message);
        return res.redirect('/admin/refund-requests');
      }

      req.flash('success', 'Refund request denied and removed');
      res.redirect('/admin/refund-requests');
    });
  }
};

module.exports = AdminController;