const Discount = require('../models/Discount');

const DiscountController = {
  // POST /api/validate-discount - Validate discount code
  validateDiscount(req, res) {
    const { code, cartTotal } = req.body;

    if (!code || !cartTotal) {
      return res.status(400).json({ valid: false, message: 'Code and cart total required' });
    }

    Discount.validateCode(code, parseFloat(cartTotal), (err, result) => {
      if (err) {
        console.error('Error validating discount:', err);
        return res.status(500).json({ valid: false, message: 'Server error' });
      }

      res.json(result);
    });
  },

  // GET /admin/discounts - List all discount codes (admin)
  listDiscounts(req, res) {
    const user = req.session.user;
    if (!user || user.role !== 'admin') {
      req.flash('error', 'Access denied');
      return res.redirect('/shopping');
    }

    Discount.getAll((err, discounts) => {
      if (err) {
        console.error('Error fetching discounts:', err);
        return res.status(500).send('Database error');
      }

      res.render('admin/discounts', { discounts, user });
    });
  },

  // GET /admin/discounts/create - Show create discount form (admin)
  showCreateForm(req, res) {
    const user = req.session.user;
    if (!user || user.role !== 'admin') {
      req.flash('error', 'Access denied');
      return res.redirect('/shopping');
    }

    res.render('admin/createDiscount', { user });
  },

  // POST /admin/discounts - Create new discount code (admin)
  createDiscount(req, res) {
    const user = req.session.user;
    if (!user || user.role !== 'admin') {
      req.flash('error', 'Access denied');
      return res.redirect('/shopping');
    }

    const { code, discountType, discountValue, description, expiryDate, usageLimit, minPurchaseAmount, maxDiscountAmount } = req.body;

    if (!code || !discountType || !discountValue) {
      req.flash('error', 'Code, type, and value are required');
      return res.redirect('/admin/discounts/create');
    }

    const discountData = {
      code,
      discountType,
      discountValue: parseFloat(discountValue),
      description,
      expiryDate: expiryDate || null,
      usageLimit: usageLimit ? parseInt(usageLimit) : null,
      minPurchaseAmount: minPurchaseAmount ? parseFloat(minPurchaseAmount) : 0,
      maxDiscountAmount: maxDiscountAmount ? parseFloat(maxDiscountAmount) : null
    };

    Discount.create(discountData, (err) => {
      if (err) {
        console.error('Error creating discount:', err);
        req.flash('error', 'Failed to create discount code');
        return res.redirect('/admin/discounts/create');
      }

      req.flash('success', `Discount code "${code}" created successfully`);
      res.redirect('/admin/discounts');
    });
  },

  // POST /admin/discounts/:code/deactivate - Deactivate discount (admin)
  deactivateDiscount(req, res) {
    const user = req.session.user;
    if (!user || user.role !== 'admin') {
      req.flash('error', 'Access denied');
      return res.redirect('/shopping');
    }

    const { code } = req.params;

    Discount.deactivate(code, (err) => {
      if (err) {
        console.error('Error deactivating discount:', err);
        req.flash('error', 'Failed to deactivate discount');
        return res.redirect('/admin/discounts');
      }

      req.flash('success', `Discount code "${code}" deactivated`);
      res.redirect('/admin/discounts');
    });
  }
};

module.exports = DiscountController;
