const Wallet = require('../models/Wallet');

const WalletController = {
  // GET /wallet - Show wallet balance and overview
  showWallet(req, res) {
    const user = req.session.user;

    Wallet.getWalletDetails(user.id, (err, wallet) => {
      if (err) {
        console.error('Error fetching wallet:', err);
        req.flash('error', 'Could not load wallet');
        return res.redirect('/shopping');
      }

      Wallet.getTransactionHistory(user.id, 10, (err2, transactions) => {
        if (err2) {
          console.error('Error fetching transactions:', err2);
          transactions = [];
        }

        res.render('wallet', { wallet: wallet || {}, transactions: transactions || [], user });
      });
    });
  },

  // GET /wallet/add-funds - Show add funds form
  showAddFundsForm(req, res) {
    const user = req.session.user;

    Wallet.getBalance(user.id, (err, balance) => {
      if (err) {
        console.error('Error fetching balance:', err);
        balance = 0;
      }

      res.render('add-funds', { balance: balance || 0, user });
    });
  },

  // POST /wallet/add-funds - Add funds to wallet instantly
  addFunds(req, res) {
    const user = req.session.user;
    const { amount } = req.body;

    // Validate amount
    const numAmount = parseFloat(amount);
    if (!numAmount || numAmount <= 0) {
      req.flash('error', 'Please enter a valid amount');
      return res.redirect('/wallet/add-funds');
    }

    if (numAmount > 9999.99) {
      req.flash('error', 'Amount cannot exceed $9999.99');
      return res.redirect('/wallet/add-funds');
    }

    // Add funds instantly
    Wallet.addFunds(user.id, numAmount, `Manual Top-up - $${numAmount.toFixed(2)}`, (err, result) => {
      if (err) {
        console.error('Error adding funds:', err);
        req.flash('error', 'Could not add funds');
        return res.redirect('/wallet/add-funds');
      }

      req.flash('success', `Successfully added $${numAmount.toFixed(2)} to your wallet!`);
      res.redirect('/wallet');
    });
  },

  // GET /wallet/history - Show full transaction history
  transactionHistory(req, res) {
    const user = req.session.user;

    Wallet.getTransactionHistory(user.id, 100, (err, transactions) => {
      if (err) {
        console.error('Error fetching transaction history:', err);
        transactions = [];
      }

      res.render('wallet-history', { transactions: transactions || [], user });
    });
  }
};

module.exports = WalletController;
