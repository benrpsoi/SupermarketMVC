const User = require('../models/User');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const db = require('../db');

const UserController = {
	showRegister(req, res) {
		res.render('register', { user: req.session.user || null, messages: req.flash('error'), formData: req.flash('formData')[0] });
	},

	register(req, res) {
		const { username, email, password, address, contact, role } = req.body;
		try {
			const hashed = bcrypt.hashSync(password, 10);
			const user = { username, email, password: hashed, address, contact, role };
			User.create(user, (err, result) => {
				if (err) {
					console.error('User create error:', err);
					req.flash('error', 'Could not create user');
					return res.redirect('/register');
				}
				req.flash('success', 'Registration successful! Please log in.');
				return res.redirect('/login');
			});
		} catch (e) {
			console.error('Registration failed', e);
			req.flash('error', 'Could not register account');
			res.redirect('/register');
		}
	},

	showLogin(req, res) {
		res.render('login', { user: req.session.user || null, messages: req.flash('success'), errors: req.flash('error') });
	},

	login(req, res) {
		const { email, password } = req.body;
		if (!email || !password) {
			req.flash('error', 'All fields are required.');
			return res.redirect('/login');
		}

		User.findByEmail(email, (err, userRec) => {
			if (err) {
				console.error('Login DB error', err);
				req.flash('error', 'Database error');
				return res.redirect('/login');
			}
			if (!userRec) {
				req.flash('error', 'Invalid email or password.');
				return res.redirect('/login');
			}

			const stored = userRec.password || '';

			const finishLogin = (u) => {
				const safe = { ...u };
				delete safe.password;
				req.session.user = safe;
				req.flash('success', 'Login successful!');
				if (req.session.user.role == 'user') return res.redirect('/shopping');
				return res.redirect('/inventory');
			};

			if (stored.startsWith('$2')) {
				if (bcrypt.compareSync(password, stored)) return finishLogin(userRec);
				req.flash('error', 'Invalid email or password.');
				return res.redirect('/login');
			}
			// fallback SHA1 legacy
			const sha1 = crypto.createHash('sha1').update(password).digest('hex');
			if (sha1 === stored) {
				// upgrade to bcrypt
				const newHash = bcrypt.hashSync(password, 10);
				db.query('UPDATE users SET password = ? WHERE id = ?', [newHash, userRec.id], (uErr) => {
					if (uErr) console.error('Failed to upgrade password:', uErr);
					finishLogin(userRec);
				});
			} else {
				req.flash('error', 'Invalid email or password.');
				return res.redirect('/login');
			}
		});
	},

	logout(req, res) {
		req.session.destroy();
		res.redirect('/');
	},

	showProfile(req, res) {
		const user = req.session.user;
		if (!user) return res.status(401).send('Not authenticated');
		res.render('profile', { user });
	}
};

module.exports = UserController;
