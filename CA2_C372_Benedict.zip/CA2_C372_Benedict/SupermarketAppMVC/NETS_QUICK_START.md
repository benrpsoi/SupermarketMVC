# NETS Integration - Quick Start Guide

## 5-Minute Setup

### Step 1: Get NETS Credentials
1. Visit https://sandbox.nets.openapipaas.com/
2. Sign up for a developer account
3. Create a new application
4. Copy your **API Key** and **Project ID**

### Step 2: Configure Environment
```bash
# In the SupermarketAppMVC directory:
cp .env.example .env
```

Edit `.env` and add your credentials:
```env
API_KEY=your_api_key_from_nets
PROJECT_ID=your_project_id_from_nets
```

### Step 3: Install Dependencies
```bash
npm install
```

### Step 4: Start the Application
```bash
npm start
# or for development with auto-reload:
npm run dev
```

The app will start at `http://localhost:3000`

### Step 5: Test NETS Payment
1. Register/Login to the application
2. Browse and add items to cart
3. Click "View Cart"
4. Click **"Pay with NETS QR"** button
5. Review order and click payment button
6. Scan the generated QR code with NETS Mobile Simulator
7. Complete the payment
8. See success confirmation

---

## Integration Files Reference

| File | Purpose | Status |
|------|---------|--------|
| `services/nets.js` | NETS API service | ✅ Created |
| `views/netsQr.ejs` | QR code display | ✅ Created |
| `views/checkoutNets.ejs` | Payment selection | ✅ Created |
| `views/netsTxnSuccessStatus.ejs` | Success page | ✅ Created |
| `views/netsTxnFailStatus.ejs` | Failure page | ✅ Created |
| `app.js` | Routes & SSE endpoint | ✅ Updated |
| `controllers/OrderController.js` | Checkout logic | ✅ Updated |
| `views/cart.ejs` | Payment options | ✅ Updated |
| `package.json` | Dependencies | ✅ Updated |
| `.env.example` | Configuration template | ✅ Created |
| `NETS_INTEGRATION_GUIDE.md` | Full documentation | ✅ Created |
| `NETS_IMPLEMENTATION_SUMMARY.md` | Changes summary | ✅ Created |
| `NETS_ARCHITECTURE.md` | System architecture | ✅ Created |

---

## User Experience Flow

```
Shopping Cart → Pay with NETS QR
                      ↓
                Payment Review
                      ↓
                Display QR Code
                (5-minute timer)
                      ↓
                Scan with NETS App
                      ↓
                Complete Payment
                      ↓
         Success Page or Failure Page
                      ↓
              View Orders / Retry
```

---

## Key Features

✅ Real-time payment status with Server-Sent Events (SSE)
✅ 5-minute payment deadline with countdown timer
✅ Automatic QR code generation from cart
✅ Success and failure notifications
✅ Full error handling and validation
✅ Session-based security
✅ Mobile-responsive design
✅ Bootstrap styling integration

---

## Testing Checklist

- [ ] NETS credentials obtained and configured
- [ ] npm install completed
- [ ] Application starts without errors
- [ ] Can add items to cart
- [ ] "Pay with NETS QR" button appears
- [ ] Payment page loads correctly
- [ ] QR code displays
- [ ] Timer counts down properly
- [ ] Can simulate payment with NETS simulator
- [ ] Success page appears on payment completion

---

## Troubleshooting

### "API_KEY or PROJECT_ID is undefined"
- Check `.env` file exists in project root
- Verify credentials are correct in `.env`
- Restart the application

### "QR Code not generating"
- Check network connection
- Verify API credentials
- Check NETS service status

### "Payment status not updating"
- Check browser console for errors
- Verify EventSource connection
- Check NETS sandbox connectivity

### "Cannot find module 'axios'"
- Run `npm install` again
- Check npm version: `npm --version`

---

## Commands Reference

```bash
# Install dependencies
npm install

# Start server
npm start

# Start with auto-reload (development)
npm run dev

# View logs
# Check console output from npm start

# Test payment flow
# 1. Add items to cart
# 2. Click "Pay with NETS QR"
# 3. Scan QR code
# 4. Complete in NETS simulator
```

---

## Environment Variables

Required variables in `.env`:
```
API_KEY=your_nets_api_key
PROJECT_ID=your_nets_project_id
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=
DB_NAME=supermarket_app
PORT=3000
NODE_ENV=development
```

---

## Security Notes

🔒 **Never commit `.env` file to version control**
🔒 **API keys should be rotated regularly**
🔒 **Use HTTPS in production**
🔒 **Keep Node.js and dependencies updated**

---

## Support Resources

- NETS Developer Portal: https://sandbox.nets.openapipaas.com/
- Full Integration Guide: See `NETS_INTEGRATION_GUIDE.md`
- Architecture Details: See `NETS_ARCHITECTURE.md`

---

## Next Steps

1. ✅ Complete steps 1-4 above
2. ✅ Test payment flow
3. 📋 Review `NETS_INTEGRATION_GUIDE.md` for detailed docs
4. 🚀 Deploy to production when ready (update endpoints)

---

**Integration Status**: ✅ Ready for Testing
**Last Updated**: January 29, 2026
