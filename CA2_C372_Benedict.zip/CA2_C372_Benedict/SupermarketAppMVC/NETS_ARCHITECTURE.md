# NETS Integration Architecture

## System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                     SupermarketMVC Application                  │
│                                                                   │
│  ┌──────────────┐     ┌──────────────┐     ┌──────────────┐    │
│  │   Frontend   │────▶│   Express    │────▶│   Database   │    │
│  │   (EJS)      │     │   Server     │     │   (MySQL)    │    │
│  └──────────────┘     └──────────────┘     └──────────────┘    │
│                              │                                   │
│                              │                                   │
│                     ┌────────▼────────┐                         │
│                     │  NETS Service   │                         │
│                     │  Integration    │                         │
│                     └────────┬────────┘                         │
│                              │                                   │
└──────────────────────────────┼──────────────────────────────────┘
                               │
                    ┌──────────▼──────────┐
                    │  NETS Sandbox API   │
                    │  (OpenAPI PaaS)     │
                    └─────────────────────┘
```

## Component Architecture

### 1. Frontend Layer (EJS Views)

```
Shopping Cart (cart.ejs)
├── Display Cart Items
├── Payment Method Selection
│   ├── Button: "Pay with NETS QR"
│   └── Button: "Direct Checkout"
└── Order Summary

    ↓ (NETS QR selected)

Checkout NETS (checkoutNets.ejs)
├── Order Summary
├── Payment Amount
└── NETS Payment Button

    ↓ (Process Payment)

NETS QR Display (netsQr.ejs)
├── QR Code Image
├── 5-Minute Timer
├── Real-time Status Updates (SSE)
└── Payment Status Messages

    ↓ (Payment Success/Failure)

Status Page (netsTxn*Status.ejs)
├── Success/Failure Message
├── Transaction Reference
└── Navigation Links
```

### 2. Application Server Layer (Node.js/Express)

```
app.js (Main Application)
│
├── Routes
│   ├── GET /checkout-nets ─────────────────▶ OrderController.checkoutNets()
│   ├── POST /generateNETSQR ────────────────▶ netsQr.generateQrCode()
│   ├── GET /nets-qr/success
│   ├── GET /nets-qr/fail
│   └── GET /sse/payment-status/:txnRef
│
├── Middleware
│   ├── Authentication (checkAuthenticated)
│   ├── Session Management
│   ├── Body Parsers
│   └── Error Handlers
│
└── Services
    └── services/nets.js
        └── generateQrCode()
            ├── Validate Cart
            ├── Build Request
            ├── Call NETS API
            ├── Parse Response
            └── Render QR Page
```

### 3. NETS API Integration

```
NETS Service (services/nets.js)

Function: generateQrCode(req, res)
│
├── Extract cartTotal from request
├── Build NETS Request
│   ├── txn_id: "sandbox_nets|..."
│   ├── amt_in_dollars: cartTotal
│   └── notify_mobile: 0
│
├── Call NETS API
│   └── POST https://sandbox.nets.openapipaas.com/api/v1/common/payments/nets-qr/request
│       Header: api-key, project-id
│
├── Handle Response
│   ├── Success: Generate QR, render view
│   └── Failure: Render error view
│
└── Return Response

Real-time Status Endpoint: /sse/payment-status/:txnRef

├── Set SSE Headers
├── Start Polling Loop (5-second intervals)
│   │
│   └── Call NETS Query API
│       └── POST https://sandbox.nets.openapipaas.com/api/v1/common/payments/nets-qr/query
│           Headers: api-key, project-id
│           Body: txn_retrieval_ref, frontend_timeout_status
│
├── Process Response
│   ├── response_code == "00" && txn_status === 1 → Success
│   ├── response_code != "00" || txn_status === 2 → Failure
│   └── Poll count >= 60 (5 min) → Timeout
│
└── Stream to Client
    └── res.write(`data: ${JSON.stringify(data)}\n\n`)
```

## Data Flow Diagrams

### QR Code Generation Flow

```
User
  │
  ├─ Add items to cart
  │
  ├─ Click "Pay with NETS QR"
  │         │
  │         ├─ GET /checkout-nets
  │         │         │
  │         │         └─ OrderController.checkoutNets()
  │         │             ├─ Validate user
  │             ├─ Calculate total
  │             └─ Render checkoutNets.ejs
  │
  ├─ Review order
  │
  └─ Click "Pay with NETS QR"
            │
            └─ POST /generateNETSQR
                │
                ├─ Extract cartTotal
                │
                ├─ Call NETS API
                │  └─ https://sandbox.nets.openapipaas.com/.../request
                │      ├─ Headers: api-key, project-id
                │      └─ Body: txn_id, amt_in_dollars, notify_mobile
                │
                ├─ Receive Response
                │  ├─ qr_code (base64)
                │  ├─ txn_retrieval_ref
                │  ├─ txn_status
                │  └─ response_code
                │
                └─ Render netsQr.ejs
                   ├─ Display QR code image
                   ├─ Start 5-minute timer
                   └─ Initialize SSE connection
```

### Payment Status Polling Flow

```
Browser (netsQr.ejs)
  │
  └─ EventSourcePolyfill.open(/sse/payment-status/:txnRef)
     │
     └─ Server Endpoint
        │
        ├─ Set SSE Headers
        │
        └─ Start Polling (5-second intervals)
           │
           ├─ Call NETS Query API
           │  └─ https://sandbox.nets.openapipaas.com/.../query
           │      ├─ Headers: api-key, project-id
           │      └─ Body: txn_retrieval_ref, frontend_timeout_status
           │
           ├─ Write Response to Stream
           │  └─ res.write(`data: ${JSON.stringify(response)}\n\n`)
           │
           ├─ Browser Receives Event
           │  └─ EventSource.onmessage()
           │
           ├─ Check Status
           │  ├─ Success? → Redirect /nets-qr/success
           │  ├─ Failure? → Redirect /nets-qr/fail
           │  ├─ Timeout? → Redirect /nets-qr/fail
           │  └─ Pending → Continue polling
           │
           └─ Close Connection
```

## Database Integration

```
User Places Order with NETS Payment
│
├─ Upon successful payment
│
├─ Fetch order from session.cart
│
├─ Call Order.create(userId, cart)
│
└─ Database
   └─ INSERT INTO orders
      ├─ user_id
      ├─ order_date
      ├─ total_amount
      ├─ status
      └─ items (in order_items table)
```

## Security Architecture

```
┌──────────────────────────────────────────────┐
│        Security & Authentication Layer       │
│                                              │
├──────────────────────────────────────────────┤
│                                              │
│ 1. Session Management                       │
│    ├─ User authentication required          │
│    ├─ Session validation on each request    │
│    └─ 7-day session timeout                 │
│                                              │
│ 2. API Key Management                       │
│    ├─ Stored in .env file                   │
│    ├─ Never exposed in frontend             │
│    └─ Passed in request headers             │
│                                              │
│ 3. Cart Validation                          │
│    ├─ Cart must not be empty                │
│    ├─ Items must be in stock                │
│    └─ Prices verified against database      │
│                                              │
│ 4. HTTPS (Production)                       │
│    ├─ All API calls over HTTPS              │
│    ├─ SSL/TLS certificates                  │
│    └─ Secure cookie transmission            │
│                                              │
│ 5. CORS Configuration                       │
│    ├─ Domain validation                     │
│    ├─ Origin checking                       │
│    └─ Credential handling                   │
│                                              │
└──────────────────────────────────────────────┘
```

## Error Handling Flow

```
Request to NETS API
│
├─ Network Error?
│  └─ Catch & Log
│     └─ Redirect to /nets-qr/fail
│
├─ API Response Error?
│  ├─ response_code != "00"
│  ├─ Render error page
│  └─ Log error details
│
├─ Missing Parameters?
│  ├─ Empty cart
│  ├─ Not authenticated
│  └─ Redirect to login/cart
│
└─ Timeout?
   ├─ Poll count >= 60
   ├─ Close connection
   └─ Redirect to timeout page
```

## Environment Configuration

```
.env File (Development)
├─ DB_HOST, DB_USER, DB_PASSWORD
├─ PORT
├─ API_KEY ─────────────▶ NETS Sandbox Credentials
├─ PROJECT_ID ──────────▶ NETS Sandbox Credentials
├─ SESSION_SECRET
└─ NODE_ENV

Config (app.js)
└─ require('dotenv').config()
   ├─ Loads .env variables
   ├─ Populates process.env
   └─ Used in NETS service calls
      ├─ process.env.API_KEY
      └─ process.env.PROJECT_ID
```

## Technology Stack

```
┌─────────────────────────────────────┐
│  Frontend                           │
├─────────────────────────────────────┤
│ ├─ EJS Templates                    │
│ ├─ Bootstrap 5 CSS Framework        │
│ ├─ EventSource Polyfill             │
│ └─ Vanilla JavaScript               │
└─────────────────────────────────────┘
           │
           │ HTTP/HTTPS
           │
┌─────────────────────────────────────┐
│  Backend                            │
├─────────────────────────────────────┤
│ ├─ Node.js Runtime                  │
│ ├─ Express.js Web Framework         │
│ ├─ Axios HTTP Client                │
│ ├─ dotenv Environment Config        │
│ ├─ express-session Session Store    │
│ └─ connect-flash Message Storage    │
└─────────────────────────────────────┘
           │
           │ Secure API Calls
           │
┌─────────────────────────────────────┐
│  NETS Sandbox OpenAPI               │
├─────────────────────────────────────┤
│ ├─ QR Code Generation               │
│ ├─ Payment Status Query              │
│ └─ Transaction Management           │
└─────────────────────────────────────┘
           │
           │ Database Queries
           │
┌─────────────────────────────────────┐
│  MySQL Database                     │
├─────────────────────────────────────┤
│ ├─ users table                      │
│ ├─ products table                   │
│ ├─ orders table                     │
│ └─ order_items table                │
└─────────────────────────────────────┘
```

## Deployment Architecture

```
Development
├─ Local NETS Sandbox Testing
├─ .env with test credentials
└─ http://localhost:3000

Staging
├─ NETS Sandbox Environment
├─ HTTPS enabled
├─ Database backup
└─ User testing

Production
├─ NETS Production Environment
├─ HTTPS mandatory
├─ API key rotation
├─ Webhook integration
├─ Load balancing
├─ Database replication
└─ Monitoring & Alerts
```

---

This architecture provides a robust, scalable, and secure implementation of NETS QR payment integration while maintaining the existing SupermarketMVC structure and functionality.
