const db = require('./db');

// Check if refunds table exists and has data
db.query('SELECT * FROM refunds', (err, results) => {
    if (err) {
        console.error('Error querying refunds:', err.message);
        db.query("SHOW TABLES LIKE 'refunds'", (err2, tables) => {
            if (err2) console.error('Show tables error:', err2);
            else console.log('Refunds table exists:', tables.length > 0);
            process.exit(0);
        });
    } else {
        console.log('Refunds found:', results.length);
        if (results.length > 0) {
            console.log('Sample refund:', JSON.stringify(results[0], null, 2));
        } else {
            console.log('No refunds in database');
        }
        process.exit(0);
    }
});
