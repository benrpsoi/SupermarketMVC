const fs = require('fs');
const db = require('./db');

const sql = fs.readFileSync('./sql/add_discount_codes.sql', 'utf8');
const statements = sql.split(';').map(s => s.trim()).filter(s => s.length > 0);

(async () => {
  try {
    for (const s of statements) {
      if (s) {
        await new Promise((resolve, reject) => {
          db.query(s, (err) => err ? reject(err) : resolve());
        });
        console.log('✓ Executed:', s.substring(0, 60) + '...');
      }
    }
    console.log('\n✓ Discount codes migration completed successfully!');
    process.exit(0);
  } catch (err) {
    console.error('✗ Error:', err.message);
    process.exit(1);
  }
})();
