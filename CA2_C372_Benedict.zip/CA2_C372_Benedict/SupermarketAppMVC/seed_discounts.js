require('dotenv').config();
const mysql = require('mysql2');

const conn = mysql.createConnection({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'supermarket'
});

conn.connect((err) => {
  if (err) {
    console.error('Connection error:', err);
    process.exit(1);
  }

  const discounts = [
    {
      code: 'SAVE10',
      discount_type: 'percentage',
      discount_value: 10,
      usage_limit: 50,
      min_purchase_amount: 0,
      max_discount_amount: 100,
      expiry_date: '2026-12-31'
    },
    {
      code: 'SAVE5',
      discount_type: 'fixed',
      discount_value: 5,
      usage_limit: 30,
      min_purchase_amount: 20,
      max_discount_amount: 5,
      expiry_date: '2026-06-30'
    },
    {
      code: 'WELCOME20',
      discount_type: 'percentage',
      discount_value: 20,
      usage_limit: 100,
      min_purchase_amount: 0,
      max_discount_amount: 999,
      expiry_date: '2026-12-31'
    },
    {
      code: 'SUMMER50',
      discount_type: 'fixed',
      discount_value: 50,
      usage_limit: 20,
      min_purchase_amount: 100,
      max_discount_amount: 50,
      expiry_date: '2026-08-31'
    }
  ];

  let inserted = 0;

  discounts.forEach((discount) => {
    const sql = 'INSERT INTO discount_codes (code, discount_type, discount_value, usage_limit, min_purchase_amount, max_discount_amount, expiry_date, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, 1)';
    
    conn.query(sql, [
      discount.code,
      discount.discount_type,
      discount.discount_value,
      discount.usage_limit,
      discount.min_purchase_amount,
      discount.max_discount_amount,
      discount.expiry_date
    ], (err) => {
      if (err) {
        console.error(`Error inserting ${discount.code}:`, err.message);
      } else {
        console.log(`✓ Created: ${discount.code}`);
        inserted++;
      }

      if (inserted === discounts.length) {
        console.log('\n✓ All discount codes created!');
        console.log('\nCreated discount codes:');
        console.log('─'.repeat(60));
        discounts.forEach(d => {
          console.log(`${d.code.padEnd(15)} | ${d.discount_type === 'percentage' ? d.discount_value + '%' : '$' + d.discount_value} | Expires: ${d.expiry_date}`);
        });
        conn.end();
        process.exit(0);
      }
    });
  });
});
