const db = require('../db');
const bcrypt = require('bcryptjs');

async function run() {
  try {
    // create admin user
    const adminPass = bcrypt.hashSync('AdminPass123!', 10);
    await new Promise((resolve, reject) => db.query(
      'INSERT INTO users (username, email, password, address, contact, role) VALUES (?, ?, ?, ?, ?, ?)',
      ['admin', 'admin@example.com', adminPass, 'Admin Address', '00000000', 'admin'],
      (err) => (err ? reject(err) : resolve())
    ));
    console.log('Inserted admin user (admin@example.com / AdminPass123!)');

    // create sample products
    const products = [
      ['Apple', 50, 0.5, 'apples.png'],
      ['Milk', 20, 1.35, 'milk.png'],
      ['Bread', 30, 1.0, 'bread.png']
    ];

    for (const p of products) {
      await new Promise((resolve, reject) => db.query(
        'INSERT INTO products (productName, quantity, price, image) VALUES (?, ?, ?, ?)',
        p,
        (err) => (err ? reject(err) : resolve())
      ));
    }

    console.log('Inserted sample products');
    db.end();
  } catch (err) {
    console.error('Seeding failed:', err);
    db.end();
    process.exit(1);
  }
}

run();
