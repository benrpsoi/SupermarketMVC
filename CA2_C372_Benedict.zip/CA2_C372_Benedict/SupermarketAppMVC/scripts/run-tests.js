const fetch = globalThis.fetch;

// start the app by requiring the entry point
require('../app');

// wait a little for server to start
const wait = (ms) => new Promise(r => setTimeout(r, ms));

(async () => {
  await wait(700);
  const base = 'http://localhost:3000';

  let cookies = [];
  const saveCookies = (res) => {
    const sc = res.headers.get('set-cookie');
    if (sc) cookies.push(sc.split(';')[0]);
  };
  const cookieHeader = () => cookies.join('; ');
  const form = (data) => new URLSearchParams(data);

  try {
    console.log('Logging in as admin...');
    let res = await fetch(base + '/login', { method: 'POST', body: form({ email: 'admin@example.com', password: 'AdminPass123!' }), redirect: 'manual' });
    saveCookies(res);
    if (res.status !== 302) {
      console.error('Login failed with status', res.status);
      process.exit(1);
    }
    console.log('Logged in');

    console.log('Fetching shopping page...');
    res = await fetch(base + '/shopping', { headers: { cookie: cookieHeader() } });
    if (res.status !== 200) throw new Error('/shopping failed ' + res.status);
    const html = await res.text();
    if (!html.includes('Apple')) throw new Error('shopping page contents invalid');
    console.log('Shopping page ok');

    console.log('Add item to cart...');
    res = await fetch(base + '/add-to-cart/1', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', cookie: cookieHeader() }, body: form({ quantity: '2'}), redirect:'manual' });
    if (![200,302].includes(res.status)) throw new Error('add-to-cart failed ' + res.status);
    console.log('Added to cart');

    console.log('View cart...');
    res = await fetch(base + '/cart', { headers: { cookie: cookieHeader() } });
    const cartHtml = await res.text();
    if (!cartHtml.includes('Apple')) throw new Error('Cart does not contain product');
    console.log('Cart OK');

    console.log('Checkout...');
    res = await fetch(base + '/checkout', { method: 'POST', headers: { cookie: cookieHeader() }, redirect:'manual' });
    if (![200,302].includes(res.status)) throw new Error('checkout failed ' + res.status);
    console.log('Checkout OK');

    console.log('Orders list...');
    res = await fetch(base + '/orders', { headers: { cookie: cookieHeader() } });
    const ordersHtml = await res.text();
    if (!ordersHtml.includes('Order ID')) throw new Error('Orders page missing order list');
    console.log('Orders page OK');

    console.log('All tests passed');
    process.exit(0);
  } catch (err) {
    console.error('E2E failed:', err);
    process.exit(1);
  }
})();
