const fs = require('fs');
const db = require('../db');

const sql = fs.readFileSync(__dirname + '/../sql/create_orders.sql', 'utf8');

// split on ; and run sequentially
const statements = sql
  .split(';')
  .map(s => s.trim())
  .filter(s => s.length > 0);

(async () => {
  try {
    for (const s of statements) {
      await new Promise((resolve, reject) => {
        db.query(s, (err) => (err ? reject(err) : resolve()));
      });
      console.log('Executed statement');
    }
    console.log('Migration completed');
    db.end();
  } catch (err) {
    console.error('Migration failed:', err);
    db.end();
    process.exit(1);
  }
})();
