// Using global fetch available in modern Node.js
const fetch = globalThis.fetch;

(async () => {
  const base = 'http://localhost:3000';

  // helper for cookie session handling
  let cookies = [];
  const saveCookies = (res) => {
    const set = res.headers.raw()['set-cookie'];
    if (set) cookies = cookies.concat(set.map(c => c.split(';')[0]));
  };
  const cookieHeader = () => cookies.join('; ');

  const form = (data) => new URLSearchParams(data);

  console.log('1) Logging in as admin');
  let res = await fetch(base + '/login', { method: 'POST', body: form({ email: 'admin@example.com', password: 'AdminPass123!' }), redirect: 'manual' });
  saveCookies(res);
  if (res.status !== 302) { console.error('Login failed', res.status); process.exit(1); }
  console.log(' → Logged in (status ' + res.status + ')');

  console.log('2) Fetch shopping page to check products');
  res = await fetch(base + '/shopping', { headers: { cookie: cookieHeader() } });
  if (res.status !== 200) { console.error('/shopping failed:', res.status); process.exit(1); }
  const html = await res.text();
  if (!html.includes('Apple')) { console.error('Product names not found on shopping page'); process.exit(1); }
  console.log(' → shopping page ok');

  console.log('3) Add item to cart (product id 1)');
  res = await fetch(base + '/add-to-cart/1', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', cookie: cookieHeader() }, body: form({ quantity: '2' }), redirect: 'manual' });
  if (![302,200].includes(res.status)) { console.error('add-to-cart failed:', res.status); process.exit(1); }
  console.log(' → added to cart');

  console.log('4) View cart');
  res = await fetch(base + '/cart', { headers: { cookie: cookieHeader() } });
  const cartHtml = await res.text();
  if (!cartHtml.includes('Apple')) { console.error('Cart does not contain added product'); process.exit(1); }
  console.log(' → cart OK');

  console.log('5) Checkout');
  res = await fetch(base + '/checkout', { method: 'POST', headers: { cookie: cookieHeader() }, redirect:'manual' });
  if (![302,200].includes(res.status)) { console.error('checkout failed:', res.status); process.exit(1); }
  console.log(' → checkout placed');

  console.log('6) Order list');
  res = await fetch(base + '/orders', { headers: { cookie: cookieHeader() } });
  const ordersHtml = await res.text();
  if (!ordersHtml.includes('Order ID')) { console.error('Orders not found'); process.exit(1); }
  console.log(' → orders listing OK');

  console.log('End-to-end checks passed.');
})();
