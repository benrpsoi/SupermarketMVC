-- Migration to add refund functionality

-- Add refund status to orders table
ALTER TABLE orders ADD COLUMN refund_status ENUM('none', 'partial', 'full') DEFAULT 'none' AFTER total;
ALTER TABLE orders ADD COLUMN refunded_amount DECIMAL(10,2) DEFAULT 0.00 AFTER refund_status;

-- Create refunds table
CREATE TABLE IF NOT EXISTS refunds (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  refund_amount DECIMAL(10,2) NOT NULL,
  refund_reason TEXT,
  refund_method VARCHAR(50) NOT NULL, -- 'stripe', 'paypal', 'nets', 'manual'
  transaction_id VARCHAR(255), -- External payment provider transaction ID
  status ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
  processed_by INT NOT NULL, -- Admin user ID
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  processed_at TIMESTAMP NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (processed_by) REFERENCES users(id)
);

-- Create refund_items table for partial refunds
CREATE TABLE IF NOT EXISTS refund_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  refund_id INT NOT NULL,
  order_item_id INT NOT NULL,
  quantity_refunded INT NOT NULL,
  refund_amount DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (refund_id) REFERENCES refunds(id) ON DELETE CASCADE,
  FOREIGN KEY (order_item_id) REFERENCES order_items(id)
);