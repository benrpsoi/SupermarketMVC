const db = require('../db');

const Wallet = {
  // Get or create wallet for a user
  getOrCreateWallet(userId, callback) {
    db.query('SELECT * FROM user_wallets WHERE user_id = ?', [userId], (err, wallets) => {
      if (err) return callback(err);
      
      if (wallets && wallets.length > 0) {
        return callback(null, wallets[0]);
      }
      
      // Create new wallet
      db.query('INSERT INTO user_wallets (user_id, balance) VALUES (?, 0)', [userId], (err2, result) => {
        if (err2) return callback(err2);
        callback(null, { id: result.insertId, user_id: userId, balance: 0 });
      });
    });
  },

  // Get wallet balance
  getBalance(userId, callback) {
    db.query('SELECT balance FROM user_wallets WHERE user_id = ?', [userId], (err, results) => {
      if (err) return callback(err);
      if (!results || results.length === 0) {
        return this.getOrCreateWallet(userId, callback);
      }
      callback(null, results[0].balance);
    });
  },

  // Add funds to wallet
  addFunds(userId, amount, description, callback) {
    this.getOrCreateWallet(userId, (err, wallet) => {
      if (err) return callback(err);

      // Ensure balance is a number
      const currentBalance = parseFloat(wallet.balance) || 0;
      const numAmount = parseFloat(amount) || 0;
      const newBalance = currentBalance + numAmount;
      
      console.log(`[Wallet.addFunds] User: ${userId}, Current: ${currentBalance}, Adding: ${numAmount}, New: ${newBalance}`);
      
      // Update wallet balance
      db.query('UPDATE user_wallets SET balance = ? WHERE user_id = ?', [newBalance, userId], (err2) => {
        if (err2) return callback(err2);

        // Record transaction
        db.query(
          'INSERT INTO wallet_transactions (wallet_id, transaction_type, amount, description, balance_before, balance_after) VALUES (?, ?, ?, ?, ?, ?)',
          [wallet.id, 'credit', numAmount, description || 'Add Funds', currentBalance, newBalance],
          (err3) => {
            if (err3) return callback(err3);
            callback(null, { newBalance, transactionId: null });
          }
        );
      });
    });
  },

  // Deduct funds from wallet
  deductFunds(userId, amount, description, callback) {
    this.getOrCreateWallet(userId, (err, wallet) => {
      if (err) return callback(err);

      // Ensure balance is a number
      const currentBalance = parseFloat(wallet.balance) || 0;
      const numAmount = parseFloat(amount) || 0;

      if (currentBalance < numAmount) {
        return callback(new Error('Insufficient balance'));
      }

      const newBalance = currentBalance - numAmount;
      
      console.log(`[Wallet.deductFunds] User: ${userId}, Current: ${currentBalance}, Deducting: ${numAmount}, New: ${newBalance}`);
      
      // Update wallet balance
      db.query('UPDATE user_wallets SET balance = ? WHERE user_id = ?', [newBalance, userId], (err2) => {
        if (err2) return callback(err2);

        // Record transaction
        db.query(
          'INSERT INTO wallet_transactions (wallet_id, transaction_type, amount, description, balance_before, balance_after) VALUES (?, ?, ?, ?, ?, ?)',
          [wallet.id, 'debit', numAmount, description || 'Purchase', currentBalance, newBalance],
          (err3) => {
            if (err3) return callback(err3);
            callback(null, { newBalance, transactionId: null });
          }
        );
      });
    });
  },

  // Get transaction history
  getTransactionHistory(userId, limit = 20, callback) {
    db.query(
      `SELECT wt.* FROM wallet_transactions wt
       JOIN user_wallets uw ON wt.wallet_id = uw.id
       WHERE uw.user_id = ?
       ORDER BY wt.created_at DESC
       LIMIT ?`,
      [userId, limit],
      callback
    );
  },

  // Get wallet details
  getWalletDetails(userId, callback) {
    db.query(
      `SELECT uw.*, COUNT(wt.id) as transaction_count
       FROM user_wallets uw
       LEFT JOIN wallet_transactions wt ON uw.id = wt.wallet_id
       WHERE uw.user_id = ?
       GROUP BY uw.id`,
      [userId],
      (err, results) => {
        if (err) return callback(err);
        if (!results || results.length === 0) {
          return this.getOrCreateWallet(userId, callback);
        }
        callback(null, results[0]);
      }
    );
  }
};

module.exports = Wallet;
