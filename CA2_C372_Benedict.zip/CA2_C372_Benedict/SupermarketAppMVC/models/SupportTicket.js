const db = require('../db');

const SupportTicket = {
    create(ticket, callback) {
        const { userId, issueType, message, email, name } = ticket;
        const createdAt = new Date();
        const status = 'open';
        
        db.query(
            'INSERT INTO support_tickets (user_id, name, email, issue_type, message, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [userId || null, name, email, issueType, message, status, createdAt],
            callback
        );
    },

    getAll(callback) {
        db.query(
            'SELECT * FROM support_tickets ORDER BY created_at DESC',
            callback
        );
    },

    getById(id, callback) {
        db.query(
            'SELECT * FROM support_tickets WHERE id = ?',
            [id],
            callback
        );
    },

    getByUserId(userId, callback) {
        db.query(
            'SELECT * FROM support_tickets WHERE user_id = ? ORDER BY created_at DESC',
            [userId],
            callback
        );
    },

    updateStatus(id, status, callback) {
        db.query(
            'UPDATE support_tickets SET status = ? WHERE id = ?',
            [status, id],
            callback
        );
    },

    addReply(id, reply, repliedBy, callback) {
        const repliedAt = new Date();
        db.query(
            'UPDATE support_tickets SET reply = ?, replied_by = ?, replied_at = ?, status = ? WHERE id = ?',
            [reply, repliedBy, repliedAt, 'resolved', id],
            callback
        );
    },

    searchTickets(searchTerm, callback) {
        db.query(
            'SELECT * FROM support_tickets WHERE name LIKE ? OR email LIKE ? OR message LIKE ? ORDER BY created_at DESC',
            [`%${searchTerm}%`, `%${searchTerm}%`, `%${searchTerm}%`],
            callback
        );
    }
};

module.exports = SupportTicket;
