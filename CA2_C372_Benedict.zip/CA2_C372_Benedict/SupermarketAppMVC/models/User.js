const db = require('../db');

const User = {
  // Create a new user object: { username, email, password, address, contact, role }
  create(user, callback) {
    const sql = 'INSERT INTO users (username, email, password, address, contact, role) VALUES (?, ?, ?, ?, ?, ?)';
    const params = [user.username, user.email, user.password, user.address, user.contact, user.role];
    db.query(sql, params, (err, result) => callback(err, result));
  },

  findByEmail(email, callback) {
    db.query('SELECT * FROM users WHERE email = ?', [email], (err, results) => callback(err, results && results[0] ? results[0] : null));
  },

  getById(id, callback) {
    db.query('SELECT * FROM users WHERE id = ?', [id], (err, results) => callback(err, results && results[0] ? results[0] : null));
  }
};

module.exports = User;
