const db = require('../db');

const Refund = {
  // Create a new refund
  create(orderId, refundData, callback) {
    const { refundAmount, refundReason, refundMethod, transactionId, processedBy, refundItems } = refundData;

    // Start transaction
    db.beginTransaction((err) => {
      if (err) return callback(err);

      // Insert refund record
      const refundQuery = `
        INSERT INTO refunds (order_id, refund_amount, refund_reason, refund_method, transaction_id, processed_by, status)
        VALUES (?, ?, ?, ?, ?, ?, 'pending')
      `;

      db.query(refundQuery, [orderId, refundAmount, refundReason, refundMethod, transactionId, processedBy], (err, result) => {
        if (err) {
          return db.rollback(() => callback(err));
        }

        const refundId = result.insertId;

        // Insert refund items if partial refund
        if (refundItems && refundItems.length > 0) {
          const itemValues = refundItems.map(item => [refundId, item.orderItemId, item.quantity, item.amount]);
          db.query('INSERT INTO refund_items (refund_id, order_item_id, quantity_refunded, refund_amount) VALUES ?', [itemValues], (err2) => {
            if (err2) {
              return db.rollback(() => callback(err2));
            }

            // Update order refund status
            this.updateOrderRefundStatus(orderId, (err3) => {
              if (err3) {
                return db.rollback(() => callback(err3));
              }

              db.commit((err4) => {
                if (err4) {
                  return db.rollback(() => callback(err4));
                }
                callback(null, { refundId, refundAmount });
              });
            });
          });
        } else {
          // Full refund - update order status
          this.updateOrderRefundStatus(orderId, (err3) => {
            if (err3) {
              return db.rollback(() => callback(err3));
            }

            db.commit((err4) => {
              if (err4) {
                return db.rollback(() => callback(err4));
              }
              callback(null, { refundId, refundAmount });
            });
          });
        }
      });
    });
  },

  // Update refund status
  updateStatus(refundId, status, transactionId, callback) {
    const updateData = { status };
    if (transactionId) updateData.transaction_id = transactionId;
    if (status === 'completed') updateData.processed_at = new Date();

    db.query('UPDATE refunds SET ? WHERE id = ?', [updateData, refundId], (err, result) => {
      if (err) return callback(err);

      // If completed, update order refund status
      if (status === 'completed') {
        db.query('SELECT order_id FROM refunds WHERE id = ?', [refundId], (err2, refunds) => {
          if (err2) return callback(err2);
          if (refunds.length > 0) {
            this.updateOrderRefundStatus(refunds[0].order_id, callback);
          } else {
            callback(null);
          }
        });
      } else {
        callback(null);
      }
    });
  },

  // Update order refund status based on refunds
  updateOrderRefundStatus(orderId, callback) {
    const query = `
      SELECT
        o.total,
        COALESCE(SUM(r.refund_amount), 0) as total_refunded
      FROM orders o
      LEFT JOIN refunds r ON o.id = r.order_id AND r.status = 'completed'
      WHERE o.id = ?
      GROUP BY o.id
    `;

    db.query(query, [orderId], (err, results) => {
      if (err) return callback(err);

      if (results.length > 0) {
        const { total, total_refunded } = results[0];
        let refundStatus = 'none';
        let refundedAmount = total_refunded;

        if (total_refunded > 0) {
          if (total_refunded >= total) {
            refundStatus = 'full';
          } else {
            refundStatus = 'partial';
          }
        }

        db.query(
          'UPDATE orders SET refund_status = ?, refunded_amount = ? WHERE id = ?',
          [refundStatus, refundedAmount, orderId],
          callback
        );
      } else {
        callback(null);
      }
    });
  },

  // Get refunds for an order
  getByOrderId(orderId, callback) {
    const query = `
      SELECT r.*, u.username as processed_by_name,
             ri.order_item_id, ri.quantity_refunded, ri.refund_amount as item_refund_amount
      FROM refunds r
      LEFT JOIN users u ON r.processed_by = u.id
      LEFT JOIN refund_items ri ON r.id = ri.refund_id
      WHERE r.order_id = ?
      ORDER BY r.created_at DESC
    `;
    db.query(query, [orderId], callback);
  },

  // Get all refunds (admin)
  getAll(callback) {
    const query = `
      SELECT r.*, o.total as order_total, u.username as processed_by_name,
             cu.username as customer_name
      FROM refunds r
      JOIN orders o ON r.order_id = o.id
      JOIN users u ON r.processed_by = u.id
      JOIN users cu ON o.user_id = cu.id
      ORDER BY r.created_at DESC
    `;
    db.query(query, callback);
  },

  // Get refund by ID with items
  getById(refundId, callback) {
    const query = `
      SELECT r.*, o.total as order_total, u.username as processed_by_name,
             cu.username as customer_name
      FROM refunds r
      JOIN orders o ON r.order_id = o.id
      JOIN users u ON r.processed_by = u.id
      JOIN users cu ON o.user_id = cu.id
      WHERE r.id = ?
    `;

    db.query(query, [refundId], (err, refunds) => {
      if (err) return callback(err);
      if (!refunds || refunds.length === 0) return callback(null, null);

      const refund = refunds[0];

      // Get refund items
      db.query('SELECT * FROM refund_items WHERE refund_id = ?', [refundId], (err2, items) => {
        if (err2) return callback(err2);
        refund.items = items || [];
        callback(null, refund);
      });
    });
  },

  // Restore inventory for refunded items
  restoreInventory(refundId, callback) {
    const query = `
      SELECT ri.quantity_refunded, oi.product_id
      FROM refund_items ri
      JOIN order_items oi ON ri.order_item_id = oi.id
      WHERE ri.refund_id = ?
    `;

    db.query(query, [refundId], (err, items) => {
      if (err) return callback(err);

      if (items.length === 0) return callback(null);

      let completed = 0;
      let hasError = false;

      items.forEach((item) => {
        db.query(
          'UPDATE products SET quantity = quantity + ? WHERE id = ?',
          [item.quantity_refunded, item.product_id],
          (err2) => {
            if (err2) {
              console.error('Error restoring inventory:', err2);
              hasError = true;
            }
            completed++;
            if (completed === items.length) {
              callback(hasError ? new Error('Some inventory updates failed') : null);
            }
          }
        );
      });
    });
  },

  // Customer requests a refund
  requestRefund(orderId, customerId, refundReason, callback) {
    const query = `
      INSERT INTO refunds (order_id, refund_amount, refund_reason, request_reason, requested_by, refund_method, status)
      SELECT o.id, o.total, 'Customer Refund Request', ?, ?, 'pending', 'pending'
      FROM orders o
      WHERE o.id = ? AND o.user_id = ?
    `;

    console.log('RequestRefund Query:', query);
    console.log('RequestRefund Params:', [refundReason, customerId, orderId, customerId]);

    db.query(query, [refundReason, customerId, orderId, customerId], (err, result) => {
      if (err) {
        console.error('RequestRefund Error:', err);
        return callback(err);
      }
      console.log('RequestRefund Result:', result);
      if (result.affectedRows === 0) {
        return callback(new Error('Order not found or does not belong to user'));
      }
      callback(null, { refundId: result.insertId });
    });
  },

  // Get pending refund requests for admin
  getPendingRequests(callback) {
    const query = `
      SELECT r.*, o.total as order_total, u.username as customer_name, u.email as customer_email
      FROM refunds r
      JOIN orders o ON r.order_id = o.id
      JOIN users u ON r.requested_by = u.id
      WHERE r.status = 'pending' AND r.requested_by IS NOT NULL
      ORDER BY r.created_at DESC
    `;
    db.query(query, callback);
  },

  // Get customer's refund requests
  getCustomerRefunds(customerId, callback) {
    const query = `
      SELECT r.*, o.total as order_total
      FROM refunds r
      JOIN orders o ON r.order_id = o.id
      WHERE r.requested_by = ?
      ORDER BY r.created_at DESC
    `;
    db.query(query, [customerId], callback);
  },

  // Cancel a pending refund request
  cancelRefundRequest(refundId, customerId, callback) {
    const query = `
      DELETE FROM refunds 
      WHERE id = ? AND requested_by = ? AND status = 'pending'
    `;
    db.query(query, [refundId, customerId], (err, result) => {
      if (err) return callback(err);
      if (result.affectedRows === 0) {
        return callback(new Error('Refund request not found or cannot be cancelled'));
      }
      callback(null);
    });
  },

  // Approve a customer's refund request (admin)
  approveRefundRequest(refundId, adminId, callback) {
    const query = `
      UPDATE refunds 
      SET status = 'completed', processed_by = ?, processed_at = NOW()
      WHERE id = ? AND requested_by IS NOT NULL AND status = 'pending'
    `;
    db.query(query, [adminId, refundId], (err, result) => {
      if (err) return callback(err);
      if (result.affectedRows === 0) {
        return callback(new Error('Refund request not found or cannot be approved'));
      }
      // Update order refund status
      db.query('SELECT order_id FROM refunds WHERE id = ?', [refundId], (err2, refunds) => {
        if (err2) return callback(err2);
        if (refunds.length > 0) {
          this.updateOrderRefundStatus(refunds[0].order_id, callback);
        } else {
          callback(null);
        }
      });
    });
  },

  // Deny a customer's refund request (admin)
  denyRefundRequest(refundId, callback) {
    const query = `
      DELETE FROM refunds 
      WHERE id = ? AND requested_by IS NOT NULL AND status = 'pending'
    `;
    db.query(query, [refundId], (err, result) => {
      if (err) return callback(err);
      if (result.affectedRows === 0) {
        return callback(new Error('Refund request not found or cannot be denied'));
      }
      callback(null);
    });
  }
};

module.exports = Refund;