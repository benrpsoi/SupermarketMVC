const db = require('../db');

const Order = {
  // Create a new order with optional discount. cart should be an array of { productId, productName, quantity, price }
  create(userId, cart, callback, discountCode = null, discountAmount = 0) {
    if (!cart || cart.length === 0) return callback(new Error('Cart is empty'));

    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const finalTotal = Math.max(0, total - (discountAmount || 0));

    db.query(
      'INSERT INTO orders (user_id, total, discount_code, discount_amount, final_total) VALUES (?, ?, ?, ?, ?)', 
      [userId, total, discountCode, discountAmount || 0, finalTotal], 
      (err, result) => {
        if (err) return callback(err);
        const orderId = result.insertId;

      const values = cart.map(item => [orderId, item.productId, item.productName, item.quantity, item.price]);

      db.query('INSERT INTO order_items (order_id, product_id, product_name, quantity, price) VALUES ?', [values], (err2) => {
        if (err2) return callback(err2);

        // Deduct stock for each product in the cart
        let completed = 0;
        let hasError = false;

        if (cart.length === 0) {
          return callback(null, { orderId, total });
        }

        cart.forEach((item) => {
          db.query('UPDATE products SET quantity = quantity - ? WHERE id = ?', [item.quantity, item.productId], (err3) => {
            if (err3) {
              console.error('Error updating stock:', err3);
              hasError = true;
            }
            completed++;
            if (completed === cart.length) {
              if (hasError) {
                return callback(new Error('Order created but some stock updates failed'));
              }
              callback(null, { orderId, total });
            }
          });
        });
      });
    });
  },

  // Get orders for a user
  getByUser(userId, callback) {
    db.query('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC', [userId], (err, results) => callback(err, results));
  },

  // Get items for an order
  getItems(orderId, callback) {
    db.query('SELECT * FROM order_items WHERE order_id = ?', [orderId], (err, results) => callback(err, results));
  },

  // Get order with items by id
  getById(orderId, callback) {
    db.query('SELECT * FROM orders WHERE id = ?', [orderId], (err, orders) => {
      if (err) return callback(err);
      if (!orders || orders.length === 0) return callback(null, null);
      const order = orders[0];
      db.query('SELECT * FROM order_items WHERE order_id = ?', [orderId], (err2, items) => {
        if (err2) return callback(err2);
        order.items = items;
        callback(null, order);
      });
    });
  },

  // Get all orders for admin view
  getAll(callback) {
    const query = `
      SELECT o.*, u.username, u.email
      FROM orders o
      JOIN users u ON o.user_id = u.id
      ORDER BY o.created_at DESC
    `;
    db.query(query, callback);
  }
};

module.exports = Order;
