const db = require('../db');

const Discount = {
  // Get discount by code
  getByCode(code, callback) {
    const query = `
      SELECT * FROM discount_codes 
      WHERE code = ? AND is_active = 1
    `;
    db.query(query, [code.toUpperCase()], callback);
  },

  // Validate discount code and return discount details
  validateCode(code, cartTotal, callback) {
    this.getByCode(code, (err, results) => {
      if (err) return callback(err, null);
      
      if (!results || results.length === 0) {
        return callback(null, { valid: false, message: 'Discount code not found' });
      }

      const discount = results[0];

      // Check if expired
      if (discount.expiry_date && new Date(discount.expiry_date) < new Date()) {
        return callback(null, { valid: false, message: 'Discount code has expired' });
      }

      // Check usage limit
      if (discount.usage_limit && discount.used_count >= discount.usage_limit) {
        return callback(null, { valid: false, message: 'Discount code usage limit exceeded' });
      }

      // Check minimum purchase amount
      if (cartTotal < discount.min_purchase_amount) {
        return callback(null, { 
          valid: false, 
          message: `Minimum purchase amount is $${discount.min_purchase_amount}` 
        });
      }

      // Calculate discount amount
      let discountAmount = 0;
      if (discount.discount_type === 'percentage') {
        discountAmount = (cartTotal * discount.discount_value) / 100;
      } else {
        discountAmount = discount.discount_value;
      }

      // Check max discount amount
      if (discount.max_discount_amount && discountAmount > discount.max_discount_amount) {
        discountAmount = discount.max_discount_amount;
      }

      // Don't allow discount to make total negative
      if (discountAmount > cartTotal) {
        discountAmount = cartTotal;
      }

      callback(null, {
        valid: true,
        code: discount.code,
        discountAmount: parseFloat(discountAmount.toFixed(2)),
        discountType: discount.discount_type,
        discountValue: discount.discount_value,
        message: `Discount applied: -$${discountAmount.toFixed(2)}`
      });
    });
  },

  // Apply discount to order (increment usage count)
  applyToOrder(code, callback) {
    const query = `
      UPDATE discount_codes 
      SET used_count = used_count + 1 
      WHERE code = ?
    `;
    db.query(query, [code.toUpperCase()], callback);
  },

  // Create new discount code (admin only)
  create(discountData, callback) {
    const { code, discountType, discountValue, description, expiryDate, usageLimit, minPurchaseAmount, maxDiscountAmount } = discountData;
    
    const query = `
      INSERT INTO discount_codes 
      (code, discount_type, discount_value, description, expiry_date, usage_limit, min_purchase_amount, max_discount_amount) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    db.query(query, [
      code.toUpperCase(),
      discountType,
      discountValue,
      description || null,
      expiryDate || null,
      usageLimit || null,
      minPurchaseAmount || 0,
      maxDiscountAmount || null
    ], callback);
  },

  // Get all active discount codes
  getAll(callback) {
    const query = `
      SELECT * FROM discount_codes 
      ORDER BY created_at DESC
    `;
    db.query(query, callback);
  },

  // Deactivate discount code
  deactivate(code, callback) {
    const query = `
      UPDATE discount_codes 
      SET is_active = 0 
      WHERE code = ?
    `;
    db.query(query, [code.toUpperCase()], callback);
  }
};

module.exports = Discount;
