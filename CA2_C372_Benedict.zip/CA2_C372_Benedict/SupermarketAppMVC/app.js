const express = require('express');
// MySQL connection is handled in `db.js` (reads from .env). Import single shared connection.
const db = require('./db');
const session = require('express-session');
const flash = require('connect-flash');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const multer = require('multer');
const axios = require('axios');
const app = express();
const OrderController = require('./controllers/OrderController');
const ProductController = require('./controllers/ProductController');
const UserController = require('./controllers/UserController');
const SupportController = require('./controllers/SupportController');
const AdminController = require('./controllers/AdminController');
const DiscountController = require('./controllers/DiscountController');
const netsQr = require('./services/nets');
const paypal = require('./services/paypal');
const stripe = require('./services/stripe');

// Load environment variables
require('dotenv').config();

// Set up multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/images'); // Directory to save uploaded files
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname); 
    }
});

const upload = multer({ storage: storage });

// removed duplicate hard-coded connection — using db.js shared connection

// Set up view engine
app.set('view engine', 'ejs');
//  enable static files
app.use(express.static('public'));
// enable form processing
app.use(express.urlencoded({
    extended: false
}));
// enable JSON parsing for API requests
app.use(express.json());

//TO DO: Insert code for Session Middleware below 
app.use(session({
    secret: 'secret',
    resave: false,
    saveUninitialized: true,
    // Session expires after 1 week of inactivity
    cookie: { maxAge: 1000 * 60 * 60 * 24 * 7 } 
}));

app.use(flash());

// Global middleware to make flash messages available to all views
app.use((req, res, next) => {
    res.locals.messages = {
        success: req.flash('success'),
        error: req.flash('error')
    };
    next();
});

// Create support_tickets table if it doesn't exist
db.query(`
    CREATE TABLE IF NOT EXISTS support_tickets (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        issue_type VARCHAR(100) NOT NULL,
        message TEXT NOT NULL,
        reply TEXT,
        replied_by VARCHAR(255),
        status VARCHAR(50) DEFAULT 'open',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        replied_at TIMESTAMP NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    )
`, (err) => {
    if (err) console.error('Error creating support_tickets table:', err);
});

// Create chat_logs table for storing all chatbot conversations
db.query(`
    CREATE TABLE IF NOT EXISTS chat_logs (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT,
        session_id VARCHAR(255),
        user_message TEXT NOT NULL,
        bot_response TEXT NOT NULL,
        context_data JSON,
        escalated BOOLEAN DEFAULT 0,
        ticket_id INT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
        FOREIGN KEY (ticket_id) REFERENCES support_tickets(id) ON DELETE SET NULL,
        INDEX(user_id),
        INDEX(session_id),
        INDEX(created_at)
    )
`, (err) => {
    if (err) console.error('Error creating chat_logs table:', err);
});

// Migrate refunds table to support customer refund requests
db.query(`
    ALTER TABLE refunds 
    ADD COLUMN requested_by INT AFTER processed_by
`, (err) => {
    // Column might already exist, that's fine
});

db.query(`
    ALTER TABLE refunds 
    ADD COLUMN request_reason TEXT AFTER refund_reason
`, (err) => {
    // Column might already exist, that's fine
});

// Create user_wallets table for wallet functionality
db.query(`
    CREATE TABLE IF NOT EXISTS user_wallets (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL UNIQUE,
        balance DECIMAL(10,2) DEFAULT 0.00,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )
`, (err) => {
    if (err) console.error('Error creating user_wallets table:', err);
});

// Create wallet_transactions table to track all wallet transactions
db.query(`
    CREATE TABLE IF NOT EXISTS wallet_transactions (
        id INT PRIMARY KEY AUTO_INCREMENT,
        wallet_id INT NOT NULL,
        transaction_type ENUM('credit', 'debit') NOT NULL,
        amount DECIMAL(10,2) NOT NULL,
        description VARCHAR(255),
        balance_before DECIMAL(10,2),
        balance_after DECIMAL(10,2),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (wallet_id) REFERENCES user_wallets(id) ON DELETE CASCADE
    )
`, (err) => {
    if (err) console.error('Error creating wallet_transactions table:', err);
});

// Middleware to check if user is logged in
const checkAuthenticated = (req, res, next) => {
    if (req.session.user) {
        return next();
    } else {
        req.flash('error', 'Please log in to view this resource');
        res.redirect('/login');
    }
};

// Middleware to check if user is admin
const checkAdmin = (req, res, next) => {
    if (req.session.user.role === 'admin') {
        return next();
    } else {
        req.flash('error', 'Access denied');
        res.redirect('/shopping');
    }
};

// Middleware for form validation
const validateRegistration = (req, res, next) => {
    const { username, email, password, address, contact, role } = req.body;

    if (!username || !email || !password || !address || !contact || !role) {
        return res.status(400).send('All fields are required.');
    }
    
    if (password.length < 6) {
        req.flash('error', 'Password should be at least 6 or more characters long');
        req.flash('formData', req.body);
        return res.redirect('/register');
    }
    next();
};

// Define routes
app.get('/',  (req, res) => {
    res.render('index', {user: req.session.user} );
});

app.get('/inventory', checkAuthenticated, checkAdmin, ProductController.listAll);

app.get('/register', UserController.showRegister);

app.post('/register', validateRegistration, UserController.register);

app.get('/login', UserController.showLogin);

app.post('/login', (req, res) => {
    const { email, password } = req.body;

    // Validate email and password
    if (!email || !password) {
        req.flash('error', 'All fields are required.');
        return res.redirect('/login');
    }

    // delegate to controller
    return UserController.login(req, res);
});

app.get('/shopping', checkAuthenticated, ProductController.listAll);

app.post('/add-to-cart/:id', checkAuthenticated, (req, res) => {
    const productId = parseInt(req.params.id);
    const quantity = parseInt(req.body.quantity) || 1;

    db.query('SELECT * FROM products WHERE id = ?', [productId], (error, results) => {
        if (error) throw error;

        if (results.length > 0) {
            const product = results[0];

            // Initialize cart in session if not exists
            if (!req.session.cart) {
                req.session.cart = [];
            }

            // Check if product already in cart
            const existingItem = req.session.cart.find(item => item.productId === productId);
            if (existingItem) {
                existingItem.quantity += quantity;
            } else {
                // store productId consistently so we can find/remove/update items
                req.session.cart.push({
                    productId: product.id,
                    productName: product.productName,
                    price: product.price,
                    quantity: quantity,
                    image: product.image
                });
            }

            res.redirect('/cart');
        } else {
            res.status(404).send("Product not found");
        }
    });
});

app.get('/cart', checkAuthenticated, (req, res) => {
    const cart = req.session.cart || [];
    res.render('cart', { cart, user: req.session.user });
});

// Update cart item quantity
app.post('/cart/update/:id', checkAuthenticated, (req, res) => {
    const productId = parseInt(req.params.id);
    const quantity = parseInt(req.body.quantity) || 0;

    if (!req.session.cart) return res.redirect('/cart');

    const item = req.session.cart.find(i => i.productId === productId);
    if (item) {
        if (quantity <= 0) {
            // remove the item
            req.session.cart = req.session.cart.filter(i => i.productId !== productId);
        } else {
            item.quantity = quantity;
        }
    }

    res.redirect('/cart');
});

// Remove an item from cart
app.post('/cart/remove/:id', checkAuthenticated, (req, res) => {
    const productId = parseInt(req.params.id);
    if (!req.session.cart) return res.redirect('/cart');
    req.session.cart = req.session.cart.filter(i => i.productId !== productId);
    res.redirect('/cart');
});

// Clear whole cart
app.post('/cart/clear', checkAuthenticated, (req, res) => {
    req.session.cart = [];
    res.redirect('/cart');
});

// Checkout route — create order from session cart
app.post('/checkout', checkAuthenticated, OrderController.checkout);

// NETS Payment Integration Routes
app.post('/generateNETSQR', checkAuthenticated, netsQr.generateQrCode);
app.get("/nets-qr/success", checkAuthenticated, (req, res) => {
    const user = req.session.user;
    const cart = req.session.cart || [];

    if (cart.length === 0) {
        // Cart already cleared, just render success page
        return res.render('netsTxnSuccessStatus', { 
            message: 'Transaction Successful!',
            user: req.session.user,
            txnRef: req.query.txn_retrieval_ref 
        });
    }

    // Calculate total
    let cartTotal = 0;
    cart.forEach(item => {
      cartTotal += item.price * item.quantity;
    });

    // Create the order
    const Order = require('./models/Order');
    Order.create(user.id, cart, (err, result) => {
        if (err) {
            console.error('Error creating order for NETS payment:', err);
            req.flash('error', 'Payment succeeded but order creation failed. Please contact support.');
            return res.redirect('/cart');
        }

        // Clear cart
        req.session.cart = [];
        req.flash('success', 'Order placed successfully');

        res.render('netsTxnSuccessStatus', { 
            message: 'Transaction Successful!',
            user: req.session.user,
            txnRef: req.query.txn_retrieval_ref 
        });
    });
});
app.get("/nets-qr/fail", (req, res) => {
    res.render('netsTxnFailStatus', { 
        message: 'Transaction Failed. Please try again.',
        user: req.session.user,
        txnRef: req.query.txn_retrieval_ref 
    });
});

// Server-Sent Events (SSE) endpoint for real-time payment status polling
app.get('/sse/payment-status/:txnRetrievalRef', async (req, res) => {
    res.set({
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive'
    });

    const txnRetrievalRef = req.params.txnRetrievalRef;
    let pollCount = 0;
    const maxPolls = 60; // 5 minutes if polling every 5s
    let frontendTimeoutStatus = 0;

    const interval = setInterval(async () => {
        pollCount++;

        try {
            // Call the NETS query API
            const response = await axios.post(
                'https://sandbox.nets.openapipaas.com/api/v1/common/payments/nets-qr/query',
                { txn_retrieval_ref: txnRetrievalRef, frontend_timeout_status: frontendTimeoutStatus },
                {
                    headers: {
                        'api-key': process.env.API_KEY,
                        'project-id': process.env.PROJECT_ID,
                        'Content-Type': 'application/json'
                    }
                }
            );

            console.log("Polling response:", response.data);
            // Send the full response to the frontend
            res.write(`data: ${JSON.stringify(response.data)}\n\n`);
        
            const resData = response.data.result.data;

            // Decide when to end polling and close the connection
            // Check if payment is successful
            if (resData.response_code == "00" && resData.txn_status === 1) {
                // Payment success: send a success message
                res.write(`data: ${JSON.stringify({ success: true })}\n\n`);
                clearInterval(interval);
                res.end();
            } else if (frontendTimeoutStatus == 1 && resData && (resData.response_code !== "00" || resData.txn_status === 2)) {
                // Payment failure: send a fail message
                res.write(`data: ${JSON.stringify({ fail: true, ...resData })}\n\n`);
                clearInterval(interval);
                res.end();
            }

        } catch (err) {
            clearInterval(interval);
            res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`);
            res.end();
        }

        // Timeout
        if (pollCount >= maxPolls) {
            clearInterval(interval);
            frontendTimeoutStatus = 1;
            res.write(`data: ${JSON.stringify({ fail: true, error: "Timeout" })}\n\n`);
            res.end();
        }
    }, 5000);

    req.on('close', () => {
        clearInterval(interval);
    });
});

// Order history and invoice
app.get('/checkout-nets', checkAuthenticated, OrderController.checkoutNets);
app.get('/checkout-paypal', checkAuthenticated, OrderController.checkoutPaypal);
app.get('/checkout-stripe', checkAuthenticated, OrderController.checkoutStripe);
app.get('/checkout-wallet', checkAuthenticated, OrderController.checkoutWallet);
app.post('/checkout-wallet', checkAuthenticated, OrderController.processWalletCheckout);
app.get('/orders', checkAuthenticated, OrderController.list);
app.get('/orders/:id/request-refund', checkAuthenticated, OrderController.showRefundRequestForm);
app.post('/orders/:id/request-refund', checkAuthenticated, OrderController.requestRefund);
app.get('/my-refunds', checkAuthenticated, OrderController.myRefunds);
app.get('/orders/:id/invoice', checkAuthenticated, OrderController.invoice);

// User profile
app.get('/profile', checkAuthenticated, UserController.showProfile);

// Wallet routes
const WalletController = require('./controllers/WalletController');
app.get('/wallet', checkAuthenticated, WalletController.showWallet);
app.get('/wallet/add-funds', checkAuthenticated, WalletController.showAddFundsForm);
app.post('/wallet/add-funds', checkAuthenticated, WalletController.addFunds);
app.get('/wallet/history', checkAuthenticated, WalletController.transactionHistory);

// Support routes - User
app.get('/support', SupportController.showSupport);
app.post('/support', SupportController.createTicket);
app.get('/my-tickets', checkAuthenticated, SupportController.myTickets);

// Chatbot API endpoint - Advanced AI with context awareness
app.post('/api/chat', (req, res) => {
    const { message, sessionId } = req.body;
    const userId = req.session.user ? req.session.user.id : null;

    if (!message || message.trim().length === 0) {
        return res.status(400).json({ error: 'Message cannot be empty' });
    }

    // Get real-time product data
    db.query('SELECT id, productName, price, quantity FROM products', (err, products) => {
        if (err) {
            console.error('Error fetching products:', err);
            return res.status(500).json({ error: 'Database error' });
        }

        const userMsg = message.toLowerCase().trim();
        let botResponse = '';
        let contextData = { products_available: products.length, user_asked: userMsg };
        let shouldEscalate = false;

        // Advanced AI Response Logic (20+ categories)
        if (userMsg.includes('stock') || userMsg.includes('available') || userMsg.includes('how many')) {
            const productMatch = products.filter(p => userMsg.includes(p.productName.toLowerCase()));
            if (productMatch.length > 0) {
                const product = productMatch[0];
                botResponse = `📦 We have ${product.quantity} units of ${product.productName} in stock at $${product.price}. ${product.quantity < 5 ? '⚠️ Low stock - order soon!' : 'Plenty available!'}`;
                contextData.product_searched = product.productName;
            } else {
                const lowStockItems = products.filter(p => p.quantity < 5 && p.quantity > 0);
                if (lowStockItems.length > 0) {
                    botResponse = `All products are in stock! However, ${lowStockItems[0].productName} is running low (${lowStockItems[0].quantity} left). Would you like alternatives?`;
                } else {
                    botResponse = `✅ All our products have good stock levels! Visit our Shop page to browse. Is there a specific product you're looking for?`;
                }
            }
        } else if (userMsg.includes('recommend') || userMsg.includes('suggest') || userMsg.includes('best selling')) {
            const inStockProducts = products.filter(p => p.quantity > 0);
            if (inStockProducts.length > 0) {
                const randomProduct = inStockProducts[Math.floor(Math.random() * inStockProducts.length)];
                botResponse = `⭐ I recommend ${randomProduct.productName}! It's priced at $${randomProduct.price} and we have ${randomProduct.quantity} in stock. Would you like to add it to your cart?`;
                contextData.recommended_product = randomProduct.productName;
            } else {
                botResponse = `Currently out of stock. Check back soon!`;
            }
        } else if (userMsg.includes('price') || userMsg.includes('cost') || userMsg.includes('how much')) {
            const priceMatch = products.find(p => userMsg.includes(p.productName.toLowerCase()));
            if (priceMatch) {
                botResponse = `💰 ${priceMatch.productName} is $${priceMatch.price}. ${priceMatch.quantity === 0 ? 'Currently out of stock.' : 'In stock and ready to order!'}`;
            } else {
                botResponse = `💰 Our prices vary by product. Visit our Shop page to see current pricing. We also run regular promotions!`;
            }
        } else if (userMsg.includes('out of stock') || userMsg.includes('unavailable')) {
            const outOfStock = products.filter(p => p.quantity === 0);
            if (outOfStock.length > 0) {
                botResponse = `We have ${outOfStock.length} items temporarily out of stock. Would you like me to suggest similar items in stock?`;
            } else {
                botResponse = `Great news! All our products are currently in stock. 📦 Browse our Shop now!`;
            }
        } else if (userMsg.includes('alternative') || userMsg.includes('similar')) {
            const inStockItems = products.filter(p => p.quantity > 0);
            if (inStockItems.length > 1) {
                const randomAlternative = inStockItems[Math.floor(Math.random() * inStockItems.length)];
                botResponse = `🔄 Here's an alternative: ${randomAlternative.productName} at $${randomAlternative.price} with ${randomAlternative.quantity} units available.`;
                contextData.alternative_suggested = randomAlternative.productName;
            } else {
                botResponse = `Visit our Shop to see all available alternatives.`;
            }
        } else if (userMsg.includes('discount') || userMsg.includes('promotion') || userMsg.includes('sale')) {
            botResponse = `🎉 We run regular promotions and seasonal sales! Subscribe to our newsletter for exclusive discounts. Many items are already on sale - check the Shop page!`;
        } else if (userMsg.includes('delivery') || userMsg.includes('shipping') || userMsg.includes('how long')) {
            botResponse = `🚚 Delivery Options:\n• Next-day delivery: Orders before 2 PM (weekdays)\n• Standard: 3-5 business days\n• Express: Same-day in select areas\n📍 Free shipping on orders over $50!`;
        } else if (userMsg.includes('refund') || userMsg.includes('return') || userMsg.includes('money back')) {
            botResponse = `↩️ Refund Policy:\n• 30-day money-back guarantee on most items\n• Fresh produce: 7-day window\n• Full refund for defective products\n• Items must be unopened/unused for standard returns\nContact us for hassle-free returns!`;
        } else if (userMsg.includes('payment') || userMsg.includes('card') || userMsg.includes('accept')) {
            botResponse = `💳 Payment Methods:\n✅ Credit Cards (Visa, Mastercard, Amex)\n✅ PayPal\n✅ Apple Pay & Google Pay\n✅ Bank Transfers\n🔒 All transactions are secure with SSL encryption`;
        } else if (userMsg.includes('login') || userMsg.includes('sign in') || userMsg.includes('account')) {
            botResponse = `🔐 Account Help:\n• Click "Sign In" in the navbar to log in\n• New user? Click "Register" to create an account\n• Forgot password? Email support@benedicts.com\n• Account issues? Our team is here 24/7!`;
        } else if (userMsg.includes('forgot') || userMsg.includes('password') || userMsg.includes('reset')) {
            botResponse = `🔑 Password Reset:\nEmail support@benedicts.com with your account details. We'll reset it within 24 hours. For urgent help, call +1 (555) 123-4567.`;
        } else if (userMsg.includes('order') || userMsg.includes('track')) {
            botResponse = `📋 Order Tracking:\n• View all orders in your profile\n• Track real-time delivery status\n• Email updates at each stage\n• Questions? Check your order details or contact us!`;
        } else if (userMsg.includes('profile') || userMsg.includes('account information')) {
            botResponse = `👤 Profile Management:\n• View/update personal info\n• See order history\n• Manage delivery addresses\n• View past support tickets\nLog in to access your profile!`;
        } else if (userMsg.includes('help') || userMsg.includes('support') || userMsg.includes('what can you do')) {
            botResponse = `🤖 I can help with:\n📦 Product & stock info\n💰 Pricing & promotions\n🚚 Delivery & shipping\n💳 Payment methods\n↩️ Returns & refunds\n📋 Orders & tracking\n🔐 Account & login\n⏰ Store hours\n📞 Contact information\nJust ask me anything!`;
        } else if (userMsg.includes('hours') || userMsg.includes('time') || userMsg.includes('open')) {
            botResponse = `⏰ Support Hours:\n📞 Phone: Mon-Fri 9AM-6PM, Sat-Sun 10AM-4PM EST\n📧 Email: 24/7 support available\n💬 Chat: Available 24/7\nWe're always here to help!`;
        } else if (userMsg.includes('location') || userMsg.includes('store') || userMsg.includes('address')) {
            botResponse = `🏪 Store Information:\nOnline Shopping: Available 24/7\n📞 Support: +1 (555) 123-4567\n📧 Email: support@benedicts.com\nVisit our Shop page for all products!`;
        } else if (userMsg.includes('quality') || userMsg.includes('guarantee')) {
            botResponse = `✨ Quality Guarantee:\n✅ Fresh, premium products\n✅ Quality inspection before delivery\n✅ 30-day satisfaction guarantee\n✅ Hassle-free returns\n🏆 Trusted by thousands of customers!`;
        } else if (userMsg.includes('hello') || userMsg.includes('hi') || userMsg.includes('hey')) {
            botResponse = `👋 Hello! Welcome to Benedict's Supermarket! How can I assist you today? Ask about products, pricing, delivery, or anything else!`;
        } else if (userMsg.includes('thank') || userMsg.includes('thanks')) {
            botResponse = `😊 You're welcome! Anything else I can help with? I'm here 24/7!`;
        } else if (userMsg.includes('bye') || userMsg.includes('goodbye')) {
            botResponse = `👋 Thank you for choosing Benedict's Supermarket! Come back soon! 🛒`;
        } else if (userMsg === '') {
            botResponse = `Please type a message to continue chatting with our AI assistant.`;
        } else {
            // Fallback with escalation suggestion
            shouldEscalate = true;
            botResponse = `That's a great question! For complex queries or urgent matters, I can escalate this to our support team. Would you like me to create a support ticket? You can also:\n📞 Call us: +1 (555) 123-4567\n📧 Email: support@benedicts.com\n💬 Live agent: Coming soon!`;
            contextData.escalation_suggested = true;
        }

        // Save chat log to database
        const context = JSON.stringify(contextData);
        db.query(
            'INSERT INTO chat_logs (user_id, session_id, user_message, bot_response, context_data, escalated) VALUES (?, ?, ?, ?, ?, ?)',
            [userId, sessionId, message, botResponse, context, shouldEscalate ? 1 : 0],
            (err, result) => {
                if (err) console.error('Error saving chat log:', err);
            }
        );

        res.json({
            success: true,
            response: botResponse,
            escalated: shouldEscalate,
            context: contextData
        });
    });
});

// Get chat history for user
app.get('/api/chat/history/:sessionId', (req, res) => {
    const { sessionId } = req.params;
    const userId = req.session.user ? req.session.user.id : null;

    db.query(
        'SELECT user_message, bot_response, created_at FROM chat_logs WHERE session_id = ? ORDER BY created_at DESC LIMIT 50',
        [sessionId],
        (err, results) => {
            if (err) {
                console.error('Error fetching chat history:', err);
                return res.status(500).json({ error: 'Database error' });
            }
            res.json({ success: true, history: results.reverse() });
        }
    );
});

// Admin - View all chat transcripts
app.get('/admin/chat-transcripts', checkAuthenticated, checkAdmin, (req, res) => {
    db.query(`
        SELECT cl.id, cl.user_id, cl.user_message, cl.bot_response, cl.escalated, cl.created_at, 
               u.username, u.email, COUNT(*) as message_count
        FROM chat_logs cl
        LEFT JOIN users u ON cl.user_id = u.id
        GROUP BY cl.user_id, DATE(cl.created_at)
        ORDER BY cl.created_at DESC
        LIMIT 100
    `, (err, transcripts) => {
        if (err) {
            console.error('Error fetching transcripts:', err);
            req.flash('error', 'Failed to load transcripts');
            return res.redirect('/inventory');
        }
        res.render('admin-chat-transcripts', { user: req.session.user, transcripts });
    });
});

// Admin - View detailed chat session
app.get('/admin/chat-session/:userId/:date', checkAuthenticated, checkAdmin, (req, res) => {
    const { userId, date } = req.params;

    db.query(`
        SELECT cl.user_message, cl.bot_response, cl.escalated, cl.created_at, cl.session_id,
               u.username, u.email
        FROM chat_logs cl
        LEFT JOIN users u ON cl.user_id = u.id
        WHERE cl.user_id = ? AND DATE(cl.created_at) = ?
        ORDER BY cl.created_at ASC
    `, [userId, date], (err, messages) => {
        if (err || messages.length === 0) {
            req.flash('error', 'Chat session not found');
            return res.redirect('/admin/chat-transcripts');
        }
        res.render('admin-chat-session', { 
            user: req.session.user, 
            messages,
            sessionUser: messages[0].username,
            sessionEmail: messages[0].email,
            sessionDate: date
        });
    });
});

// Support routes - Admin
app.get('/admin/tickets', checkAuthenticated, checkAdmin, SupportController.adminTickets);
app.get('/admin/tickets/:id', checkAuthenticated, checkAdmin, SupportController.getTicket);
app.post('/admin/tickets/:id/reply', checkAuthenticated, checkAdmin, SupportController.replyTicket);
app.post('/admin/tickets/:id/status', checkAuthenticated, checkAdmin, SupportController.updateTicketStatus);
app.get('/admin/tickets/search', checkAuthenticated, checkAdmin, SupportController.searchTickets);

// Admin Refund Routes
app.get('/admin/orders', checkAuthenticated, checkAdmin, AdminController.listOrders);
app.get('/admin/refunds', checkAuthenticated, checkAdmin, AdminController.showRefunds);
app.get('/admin/orders/:id/refund', checkAuthenticated, checkAdmin, AdminController.showRefundForm);
app.post('/admin/orders/:id/refund', checkAuthenticated, checkAdmin, AdminController.processRefund);
app.post('/admin/refunds/:id/process', checkAuthenticated, checkAdmin, AdminController.processPendingRefund);
app.get('/admin/refunds/:id', checkAuthenticated, checkAdmin, AdminController.viewRefund);
app.get('/admin/refund-requests', checkAuthenticated, checkAdmin, AdminController.showRefundRequests);
app.post('/admin/refund-requests/:id/approve', checkAuthenticated, checkAdmin, AdminController.approveRefundRequest);
app.post('/admin/refund-requests/:id/deny', checkAuthenticated, checkAdmin, AdminController.denyRefundRequest);

// Admin Discount Routes
app.get('/admin/discounts', checkAuthenticated, checkAdmin, DiscountController.listDiscounts);
app.get('/admin/discounts/create', checkAuthenticated, checkAdmin, DiscountController.showCreateForm);
app.post('/admin/discounts', checkAuthenticated, checkAdmin, DiscountController.createDiscount);
app.post('/admin/discounts/:code/deactivate', checkAuthenticated, checkAdmin, DiscountController.deactivateDiscount);

// Discount API Routes (for customers)
app.post('/api/validate-discount', DiscountController.validateDiscount);

app.get('/logout', UserController.logout);

// PayPal: Create Order
app.post('/api/paypal/create-order', async (req, res) => {
  try {
    const { amount } = req.body;
    const order = await paypal.createOrder(amount);
    if (order && order.id) {
      res.json({ id: order.id });
    } else {
      res.status(500).json({ error: 'Failed to create PayPal order', details: order });
    }
  } catch (err) {
    res.status(500).json({ error: 'Failed to create PayPal order', message: err.message });
  }
});

// PayPal: Capture Order
app.post('/api/paypal/capture-order', async (req, res) => {
  try {
    const { orderID } = req.body;
    const capture = await paypal.captureOrder(orderID);
    if (capture.status === "COMPLETED") {
      // Process the order payment
      await OrderController.processPayPalPayment(req, res, capture);
    } else {
      res.status(400).json({ error: 'Payment not completed', details: capture });
    }
  } catch (err) {
    res.status(500).json({ error: 'Failed to capture PayPal order', message: err.message });
  }
});

// Stripe: Create Payment Intent
app.post('/api/stripe/create-payment-intent', async (req, res) => {
  try {
    const { amount } = req.body;
    const paymentIntent = await stripe.createPaymentIntent(amount);
    res.json({
      clientSecret: paymentIntent.client_secret,
      paymentIntentId: paymentIntent.id
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to create Stripe payment intent', message: err.message });
  }
});

// Stripe: Confirm Payment
app.post('/api/stripe/confirm-payment', async (req, res) => {
  try {
    const { paymentIntentId } = req.body;
    const paymentIntent = await stripe.retrievePaymentIntent(paymentIntentId);
    if (paymentIntent.status === 'succeeded') {
      // Process the order payment
      await OrderController.processStripePayment(req, res, paymentIntent);
    } else {
      res.status(400).json({ error: 'Payment not completed', status: paymentIntent.status });
    }
  } catch (err) {
    res.status(500).json({ error: 'Failed to confirm Stripe payment', message: err.message });
  }
});

// Wallet Payment Handler Routes
app.get('/product/:id', checkAuthenticated, ProductController.getById);

app.get('/addProduct', checkAuthenticated, checkAdmin, (req, res) => {
    res.render('addProduct', {user: req.session.user } ); 
});

app.post('/addProduct', checkAuthenticated, checkAdmin, upload.single('image'), ProductController.add);

app.get('/updateProduct/:id', checkAuthenticated, checkAdmin, ProductController.showUpdate);

app.post('/updateProduct/:id', checkAuthenticated, checkAdmin, upload.single('image'), ProductController.update);

app.get('/deleteProduct/:id', checkAuthenticated, checkAdmin, ProductController.delete);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
