const mysql = require('mysql2');
const fs = require('fs');
require('dotenv').config();

const connection = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  multipleStatements: true
});

const sql = fs.readFileSync('sql/add_refunds.sql', 'utf8');

connection.connect((err) => {
  if (err) {
    console.error('Error connecting to database:', err);
    return;
  }

  console.log('Connected to database. Running migration...');

  connection.query(sql, (err, results) => {
    if (err) {
      console.error('Error running migration:', err);
      return;
    }

    console.log('Migration completed successfully!');
    connection.end();
  });
});