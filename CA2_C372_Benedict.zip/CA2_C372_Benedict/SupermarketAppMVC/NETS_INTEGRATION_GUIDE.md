# NETS Payment Integration Guide

This guide explains how the NETS QR payment integration has been added to the SupermarketMVC application.

## Overview

The NETS integration allows customers to pay for their orders using NETS QR code scanning. The system uses the NETS Sandbox OpenAPI for testing purposes and can be switched to production endpoints when ready.

## Features

- **NETS QR Code Generation**: Generate secure QR codes for payment
- **Real-time Payment Status Polling**: Uses Server-Sent Events (SSE) to monitor payment status
- **Payment Confirmation**: Automatic order creation upon successful payment
- **Timeout Handling**: 5-minute timeout with automatic session management
- **Error Handling**: Comprehensive error responses and retry mechanisms

## File Structure

### New Files Added

1. **services/nets.js** - NETS payment service
   - `generateQrCode()` - Main function to generate NETS QR codes
   - Handles API calls to NETS sandbox environment

2. **views/netsQr.ejs** - QR Code display page
   - Shows the NETS QR code
   - Implements countdown timer
   - Real-time payment status monitoring

3. **views/checkoutNets.ejs** - Payment method selection page
   - Order summary display
   - Payment method selection (NETS QR)
   - Cart review before payment

4. **views/netsTxnSuccessStatus.ejs** - Success confirmation page
   - Transaction success message
   - Links to order history

5. **views/netsTxnFailStatus.ejs** - Failure notification page
   - Transaction failure message
   - Links to retry or contact support

6. **.env.example** - Environment configuration template

### Modified Files

1. **package.json**
   - Added `axios` (HTTP client for API calls)
   - Added `dotenv` (Environment variable management)

2. **app.js**
   - Added `require('axios')` import
   - Added `require('./services/nets')` import
   - Added `require('dotenv').config()`
   - Added NETS QR generation endpoint: `POST /generateNETSQR`
   - Added success endpoint: `GET /nets-qr/success`
   - Added failure endpoint: `GET /nets-qr/fail`
   - Added SSE endpoint: `GET /sse/payment-status/:txnRetrievalRef`
   - Added checkout NETS route: `GET /checkout-nets`

3. **controllers/OrderController.js**
   - Added `checkoutNets()` method for NETS payment flow
   - Kept existing `checkout()` method for direct checkout

4. **views/cart.ejs**
   - Added button to proceed to NETS payment
   - Updated checkout buttons to show both options

## API Endpoints

### Payment Flow Endpoints

**1. Generate NETS QR Code**
```
POST /generateNETSQR
Content-Type: application/json

Request Body:
{
  "cartTotal": "99.99"
}

Response:
Renders netsQr.ejs view with:
- qrCodeUrl: Base64 encoded QR code image
- txnRetrievalRef: Transaction reference ID
- apiKey: NETS API key
- projectId: NETS project ID
```

**2. Payment Status SSE Endpoint**
```
GET /sse/payment-status/:txnRetrievalRef

Headers:
{
  "api-key": "your_nets_api_key",
  "project-id": "your_nets_project_id"
}

Response: Server-Sent Events stream
- Polls NETS API every 5 seconds
- Returns transaction status
- Auto-closes on success or after 5 minutes timeout
```

**3. Success Confirmation**
```
GET /nets-qr/success?txn_retrieval_ref=<ref>

Renders netsTxnSuccessStatus.ejs with:
- Success message
- Transaction reference
- Links to orders and shopping
```

**4. Failure Notification**
```
GET /nets-qr/fail?txn_retrieval_ref=<ref>

Renders netsTxnFailStatus.ejs with:
- Failure message
- Transaction reference
- Links to retry or contact support
```

## User Flow

1. **Add to Cart** → Browse products and add items to cart
2. **View Cart** → Click "View Cart" from shopping page
3. **Choose Payment Method** → Click "Pay with NETS QR" button
4. **Review Order** → See order summary on checkout page
5. **Display QR Code** → QR code is displayed with 5-minute timer
6. **Scan & Pay** → Customer scans QR with banking app to complete payment
7. **Payment Confirmation** → Real-time status check via SSE
8. **Success/Failure** → Redirect to appropriate page with order confirmation or retry option

## Environment Configuration

### Required Environment Variables

Add these to your `.env` file:

```env
# NETS API Credentials (from NETS Sandbox Portal)
API_KEY=your_nets_api_key_here
PROJECT_ID=your_nets_project_id_here

# Default transaction ID (provided by NETS)
NETS_TXN_ID=sandbox_nets|m|8ff8e5b6-d43e-4786-8ac5-7accf8c5bd9b

# NETS API Endpoints
NETS_SANDBOX_URL=https://sandbox.nets.openapipaas.com/api/v1/common/payments/nets-qr/request
NETS_QUERY_URL=https://sandbox.nets.openapipaas.com/api/v1/common/payments/nets-qr/query
```

### Setup Instructions

1. **Get NETS Credentials**
   - Visit [NETS Sandbox OpenAPI Portal](https://sandbox.nets.openapipaas.com/)
   - Create an account and register your application
   - Copy your API Key and Project ID

2. **Configure Environment**
   - Copy `.env.example` to `.env`
   - Replace `your_nets_api_key_here` with your actual API key
   - Replace `your_nets_project_id_here` with your actual project ID

3. **Install Dependencies**
   ```bash
   npm install
   ```

4. **Run the Application**
   ```bash
   npm start
   # or for development with auto-reload
   npm run dev
   ```

## Testing

### Using NETS Sandbox Simulator

1. Generate a QR code by completing the payment flow
2. On the NETS payment page, scan the QR code using NETS Sandbox Mobile Simulator
3. The simulator will show payment options and confirmation

### Test Transaction IDs

The current implementation uses a default sandbox transaction ID:
```
sandbox_nets|m|8ff8e5b6-d43e-4786-8ac5-7accf8c5bd9b
```

This is provided by NETS for testing purposes. Contact NETS support to get your own transaction ID if needed.

## Security Considerations

1. **API Keys**: Store API keys in environment variables, never commit to version control
2. **HTTPS**: Use HTTPS in production for all API calls
3. **Transaction References**: All transaction references are returned in URLs - consider moving to session storage for sensitive applications
4. **CORS**: Configure CORS appropriately for your domain
5. **Session Management**: Session timeout is set to 7 days; adjust as needed

## Production Deployment

To switch from sandbox to production:

1. Update API endpoints in `services/nets.js`:
   ```javascript
   // Change from:
   https://sandbox.nets.openapipaas.com/api/v1/common/payments/nets-qr/request
   // To:
   https://api.nets.com.sg/api/v1/common/payments/nets-qr/request
   ```

2. Update environment variables with production credentials from NETS

3. Implement additional security measures:
   - Enable HTTPS
   - Add webhook verification
   - Implement payment reconciliation
   - Add audit logging

## Troubleshooting

### QR Code Not Generating

- **Check API Keys**: Verify `API_KEY` and `PROJECT_ID` are correct
- **Network Issues**: Ensure outbound HTTPS requests are allowed
- **NETS Status**: Check NETS service status page

### Payment Status Not Updating

- **EventSource Polyfill**: Verify browser supports EventSource or has polyfill loaded
- **CORS Headers**: Check that server sends proper CORS headers
- **Session Timeout**: Payment polling times out after 5 minutes

### Transaction Failed

- **Cart Empty**: Ensure cart has items before checkout
- **User Authentication**: User must be logged in
- **Amount Issues**: Verify cart total is valid for payment

## Future Enhancements

- [ ] Multiple payment method options (credit card, e-wallet)
- [ ] Payment reconciliation with bank
- [ ] Webhook integration for asynchronous payment confirmation
- [ ] Refund processing
- [ ] Payment analytics and reporting
- [ ] Loyalty points integration
- [ ] Subscription payments

## Support

For NETS integration support:
- NETS Developer Portal: https://sandbox.nets.openapipaas.com/
- NETS Technical Documentation: Available in developer portal
- Contact your NETS account manager for sandbox credentials issues

## References

- NETS OpenAPI Documentation: https://sandbox.nets.openapipaas.com/
- EventSource Polyfill: https://github.com/EventSource/eventsource
- Express.js Documentation: https://expressjs.com/
- EJS Template Engine: https://ejs.co/
