# 🧪 AI Chatbot - Testing & Demo Guide

## ✅ Quick Start: See It Working Right Now!

Your SupermarketApp is running on **http://localhost:3000**

---

## 🎬 Live Demo - Try These Steps

### Step 1: Access the Support Page
```
1. Open browser
2. Go to http://localhost:3000/support
3. Scroll down to see the support page
4. Look for the BLUE CIRCLE at bottom-right (chat button)
```

### Step 2: Open the Chat
```
1. Click the blue circular chat button at the bottom-right
2. You'll see it slide up smoothly
3. Chat widget appears with welcome message
```

### Step 3: Ask Test Questions
Try asking the chatbot any of these:

#### Product & Stock Questions
```
"Do you have milk?"
"How many units of tomatoes are in stock?"
"What's the price of organic milk?"
"Is pasta available?"
```

#### Delivery & Shipping
```
"How long for delivery?"
"Do you offer express shipping?"
"What are the shipping options?"
```

#### Account & Login
```
"How do I log in?"
"I forgot my password"
"How do I create an account?"
```

#### Refund & Returns
```
"What's your return policy?"
"Can I return items?"
"How long do I have to return?"
```

#### General Help
```
"What are your store hours?"
"What payment methods do you accept?"
"Do you have customer support?"
"Tell me about your quality guarantee"
```

#### Complex/Escalation Questions
```
"Can you hold items for 24 hours?"
"Do you accept cryptocurrency?"
"Can I get items on credit?"
```

### Step 4: Observe Features
As you chat, notice:
- ✅ **Typing Indicator** - Bot shows "..." while thinking
- ✅ **Message History** - Previous messages visible
- ✅ **Smooth Animations** - Messages fade in
- ✅ **Professional Tone** - Helpful, polite responses
- ✅ **Real Data** - Responses based on actual inventory
- ✅ **Emojis** - Professional use of emojis
- ✅ **Escalation** - Complex questions show escalation option

### Step 5: Test Escalation
```
1. Ask a complex question (see examples above)
2. Bot will show "Escalate to Support Team" button
3. Click the button
4. You'll see message about support ticket
5. Chat context is pre-filled into support form
```

### Step 6: Test on Mobile
```
1. Open http://localhost:3000/support on phone
2. Chat widget adapts to smaller screen
3. Try sending messages on mobile
4. Verify touch optimization works
5. Check portrait and landscape modes
```

---

## 👨‍💼 Admin Testing - View All Conversations

### Step 1: Login as Admin
```
1. If not logged in, go to http://localhost:3000/login
2. Login with admin credentials
3. You should see admin options in navbar
```

### Step 2: Access Chat Transcripts
```
1. Go to http://localhost:3000/admin/chat-transcripts
2. See dashboard with statistics:
   - Total Conversations count
   - Escalated Issues count
   - Active Users count
   - Average Messages per Session
```

### Step 3: View All Chats
```
1. Scroll down to see "Recent Chat Sessions" table
2. Table shows:
   - User name
   - User email
   - Number of messages
   - Status (Resolved/Escalated)
   - Date of conversation
   - View button
```

### Step 4: View Detailed Session
```
1. Click "View" button on any conversation
2. See full transcript with:
   - All user messages
   - All bot responses
   - Timestamps
   - Topic analysis
   - Conversation statistics
```

### Step 5: Analyze Metrics
```
1. See what topics are discussed
2. View conversation duration
3. Check if escalated
4. Review conversation quality
```

---

## 🧪 Technical Testing - Backend Verification

### Test 1: Check Database
```sql
-- Open MySQL client or PHPMyAdmin
-- Run this query:
SELECT * FROM chat_logs ORDER BY created_at DESC LIMIT 10;

-- You should see:
- id (auto-increment)
- user_id (customer ID)
- session_id (unique session)
- user_message (what customer asked)
- bot_response (what bot said)
- context_data (JSON with details)
- escalated (true/false flag)
- created_at (timestamp)
```

### Test 2: Check API Endpoint
```
1. Open browser console (F12)
2. Go to Network tab
3. Send a chat message
4. You should see POST request to /api/chat
5. Response should be JSON like:
{
  "success": true,
  "response": "...",
  "escalated": false,
  "context": {...}
}
```

### Test 3: Check Server Logs
```
1. Look at terminal where server runs
2. You should see:
   - No errors
   - No warnings
   - Messages about connections
3. If you see red errors, something's wrong
```

---

## 📊 Test Scenarios

### Scenario 1: Happy Path
```
1. Open chat
2. Ask "What's the price of milk?"
3. Expect: Exact price and stock level
4. Result: ✅ Should work perfectly
```

### Scenario 2: Context Awareness
```
1. Ask "Do you have milk?"
2. Bot: "Yes, we have X units at $Y"
3. Ask "Anything cheaper?"
4. Bot: Should suggest alternative
5. Result: ✅ Should remember context
```

### Scenario 3: Escalation
```
1. Ask "Can you hold items for 24 hours?"
2. Bot: Shows escalation button
3. Click escalate
4. Support form appears with chat context
5. Result: ✅ Should pre-fill form
```

### Scenario 4: Mobile Responsive
```
1. Test on desktop (1920px)
2. Test on tablet (768px)
3. Test on mobile (375px)
4. Chat widget should adapt
5. Result: ✅ Should look good everywhere
```

### Scenario 5: Session Persistence
```
1. Send message 1
2. Refresh page
3. Open chat again
4. Previous message should be there
5. Result: ✅ History persists
```

---

## ✔️ Verification Checklist

### Frontend Features
- [ ] Blue chat button visible
- [ ] Chat opens on click
- [ ] Chat closes on click
- [ ] Messages send on Enter
- [ ] Messages send on button click
- [ ] User messages appear (blue, right)
- [ ] Bot messages appear (light blue, left)
- [ ] Typing indicator shows
- [ ] Message history visible
- [ ] Escal ation button appears for complex questions
- [ ] Mobile responsive

### Backend Features
- [ ] `/api/chat` endpoint works
- [ ] Messages saved to database
- [ ] Product queries accurate
- [ ] Escalation flag sets correctly
- [ ] Session tracking works
- [ ] Context saves properly

### Admin Features
- [ ] Admin dashboard loads
- [ ] Statistics display correctly
- [ ] Transcript table shows data
- [ ] Session details visible
- [ ] Topic analysis works
- [ ] Quick actions available

### Database Features
- [ ] chat_logs table exists
- [ ] Messages insert correctly
- [ ] Queries retrieve data
- [ ] Indexes active
- [ ] No errors in logs

---

## 🐛 Troubleshooting

### Chat Button Not Visible
```
Problem: Blue chat button not showing
Solution:
1. Refresh page (Ctrl+R)
2. Check browser console for errors (F12)
3. Verify chatbot.ejs is loaded
4. Clear browser cache
```

### Messages Not Sending
```
Problem: Messages don't send
Solution:
1. Check internet connection
2. Check browser console for errors
3. Verify API endpoint is working
4. Check server logs for errors
```

### Admin Dashboard Not Accessible
```
Problem: Can't access /admin/chat-transcripts
Solution:
1. Verify you're logged in as admin
2. Check admin role is set in database
3. Verify session is active
4. Try logging out and back in
```

### Bot Not Responding
```
Problem: Bot doesn't answer questions
Solution:
1. Wait a moment (500ms delay)
2. Check server is running (Terminal shows no errors)
3. Verify database connection
4. Check MySQL is running
5. Look at server logs for errors
```

### Messages Not Saving
```
Problem: Chat logs not in database
Solution:
1. Check chat_logs table exists
2. Verify database user has INSERT permission
3. Check for SQL errors in server logs
4. Verify table structure is correct
```

---

## 📈 Performance Testing

### Response Time
```
Test: Send 10 messages
Expected: ~500ms per response
Check: Look at Network tab in browser DevTools
Result: Should show < 1 second total
```

### Concurrent Users
```
Test: Send messages from multiple tabs
Expected: All work without issues
Check: No timeout errors
Result: Should handle multiple simultaneous chats
```

### Mobile Performance
```
Test: Send message on mobile
Expected: Smooth 60 FPS
Check: No jank or stuttering
Result: Should feel responsive
```

---

## 🔍 What to Look For

### In Browser Console (F12)
✅ Should see: No red errors  
✅ Should see: API responses in Network tab  
❌ Should NOT see: CORS errors  
❌ Should NOT see: JavaScript errors  

### In Server Terminal
✅ Should see: "Server running on port 3000"  
✅ Should see: "Connected to MySQL database"  
❌ Should NOT see: Red error messages  
❌ Should NOT see: TypeError  

### In Database (MySQL)
✅ Should see: chat_logs table with data  
✅ Should see: Messages you sent  
✅ Should see: Bot responses  
❌ Should NOT see: Empty messages  

### In Admin Dashboard
✅ Should see: Statistics cards with numbers  
✅ Should see: Conversations in table  
✅ Should see: User info  
❌ Should NOT see: Broken layout  
❌ Should NOT see: Missing data  

---

## 📋 Test Report Template

Use this to document your testing:

```
Test Date: [Date]
Tested By: [Your Name]
Environment: http://localhost:3000

FRONTEND TESTS
✅/❌ Chat button visible
✅/❌ Chat opens smoothly
✅/❌ Messages send
✅/❌ Bot responds
✅/❌ History visible
✅/❌ Mobile responsive

BACKEND TESTS
✅/❌ API responds
✅/❌ Database saves
✅/❌ Queries accurate
✅/❌ No errors

ADMIN TESTS
✅/❌ Dashboard loads
✅/❌ Statistics show
✅/❌ Sessions visible

OVERALL STATUS
✅/❌ READY FOR PRODUCTION

Notes:
- [Any issues found]
- [Any improvements suggested]
```

---

## 🎓 Expected Behavior

### Normal Chat Flow
```
1. User opens support page
2. Blue chat button visible
3. User clicks button
4. Chat widget slides up
5. Welcome message shows
6. User types question
7. Message appears in blue
8. Typing indicator shows
9. Bot response appears in light blue
10. Process repeats
```

### Escalation Flow
```
1. User asks complex question
2. Bot doesn't have good answer
3. Escalation button appears
4. User clicks escalate
5. Support form appears
6. Chat context pre-filled
7. User submits form
8. Ticket created in support system
```

### Admin Flow
```
1. Admin goes to /admin/chat-transcripts
2. Sees dashboard with statistics
3. Scrolls to conversation table
4. Clicks View on a conversation
5. Sees detailed session page
6. Reviews what customer asked
7. Analyzes topics discussed
8. Creates support ticket if needed
```

---

## ✅ Go-No-Go Checklist

**MUST HAVE (Go/No-Go):**
- [ ] Chat button visible
- [ ] Chat opens
- [ ] Messages send
- [ ] Bot responds
- [ ] No console errors
- [ ] Server running
- [ ] Database saving

**SHOULD HAVE (Nice to Have):**
- [ ] Smooth animations
- [ ] Mobile responsive
- [ ] Admin dashboard working
- [ ] Escalation working
- [ ] Typing indicator showing

**IF ALL ABOVE ARE CHECKED: ✅ GO AHEAD & USE!**

---

## 🚀 You're Ready!

Everything is set up and working. Start testing now by:

1. **Opening** http://localhost:3000/support
2. **Clicking** the blue chat button
3. **Asking** any question
4. **Enjoying** your new AI chatbot! 🤖

---

## 📞 Need More Help?

See these documents:
- **CHATBOT_COMPLETE_GUIDE.md** - Full overview
- **CHATBOT_DOCUMENTATION.md** - Technical details
- **README_CHATBOT.md** - Quick summary

---

**Happy Testing!** 🎉

*If everything works, your AI chatbot is ready for production!*
